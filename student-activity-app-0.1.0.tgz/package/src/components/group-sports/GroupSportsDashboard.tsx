"use client";

import Link from "next/link";
import SchoolSubmissionsContent from "@/components/group-sports/SchoolSubmissionsContent";
import SportsScheduleContent from "@/components/group-sports/SportsScheduleContent";
import SchoolAccountsManager from "@/components/group-sports/SchoolAccountsManager";
import { FormEvent, useCallback, useEffect, useMemo, useState, type SVGProps } from "react";
import { supabase } from "@/lib/supabase";
import { downloadRosterTemplate, readRosterExcel, supportsIndividualBatch, ATHLETE_NAME_PREFIXES, ROV_PLAY_POSITIONS, type ImportedAthlete } from "@/lib/group-sports/roster-excel";

const SPORTS_COMPETITION_SLUG = "phayao-secondary-group-sports-2569";

type IconProps = SVGProps<SVGSVGElement>;

function HomeIcon(props: IconProps) {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...props}><path d="M3 10.5 12 3l9 7.5" /><path d="M5 9.5V20h5.5v-5.5h3V20H19V9.5" /></svg>;
}
function FileUploadIcon(props: IconProps) {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...props}><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/><path d="M12 17V10"/><path d="m9.5 12.5 2.5-2.5 2.5 2.5"/></svg>;
}
function CalendarGearIcon(props: IconProps) {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...props}><rect x="3" y="5" width="14" height="14" rx="2"/><path d="M7 3v4M13 3v4M3 10h14"/><circle cx="19" cy="17" r="3"/><path d="M19 12.8v1.2M19 20v1.2M15.8 17H17M21 17h1.2M16.8 14.8l.8.8M20.4 18.4l.8.8M16.8 19.2l.8-.8M20.4 15.6l.8-.8"/></svg>;
}
function SchoolIcon(props: IconProps) {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...props}><path d="M3 21h18"/><path d="M5 21V9l7-4 7 4v12"/><path d="M9 21v-5h6v5"/><path d="M8 12h.01M12 12h.01M16 12h.01"/></svg>;
}
function TrophyIcon(props: IconProps) {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...props}><path d="M8 21h8"/><path d="M12 17v4"/><path d="M7 4h10v4a5 5 0 0 1-10 0z"/><path d="M5 6H3a2 2 0 0 0 2 5h2"/><path d="M19 6h2a2 2 0 0 1-2 5h-2"/></svg>;
}
function ClipboardCheckIcon(props: IconProps) {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...props}><rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4.5h6a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1Z"/><path d="m9 13 2 2 4-4"/></svg>;
}
function CalendarCheckIcon(props: IconProps) {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...props}><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4M16 3v4M3 10h18"/><path d="m9 15 2 2 4-4"/></svg>;
}
function BarChartIcon(props: IconProps) {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...props}><path d="M4 20V10"/><path d="M10 20V4"/><path d="M16 20v-7"/><path d="M22 20V8"/></svg>;
}
function MedalIcon(props: IconProps) {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...props}><path d="m8 3 4 5 4-5"/><path d="M9.5 8 7 12"/><path d="M14.5 8 17 12"/><circle cx="12" cy="16" r="5"/><path d="m10.8 16 1 1 1.8-2"/></svg>;
}
function UserShieldIcon(props: IconProps) {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...props}><path d="M15 21a8 8 0 1 0-6 0"/><path d="M12 13a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z"/><path d="M18.5 11.5 21 12.7v3.1c0 2-1.2 3.8-3 4.5-1.8-.7-3-2.5-3-4.5v-3.1z"/></svg>;
}

type Competition = {
  id: string;
  name: string;
  academic_year: string;
  status: string;
  start_date?: string | null;
  end_date?: string | null;
};

type School = {
  id: string;
  school_code?: string | null;
  name: string;
  district?: string | null;
  province?: string | null;
  status?: string;
};

type SportEvent = {
  id: string;
  competition_id: string;
  event_code?: string | null;
  stage3_source?: string | null;
  sport_name: string;
  event_type: "team" | "individual" | "athletics";
  gender_rule: string;
  level_rule: string;
  competition_format?: string;
  max_athletes_per_entry?: number | null;
  points_win?: number;
  points_draw?: number;
  points_loss?: number;
  venue_name?: string | null;
  status: string;
};

type Entry = {
  id: string;
  competition_id: string;
  event_id: string;
  school_id: string;
  entry_type: "team" | "individual";
  entry_name: string;
  coach_name?: string | null;
  status: string;
  return_reason?: string;
  assistant_coach?: string;
  coaches?: Coach[];
  athlete_count?: number;
};

type Match = {
  id: string;
  competition_id: string;
  event_id: string;
  match_number?: string | null;
  group_name?: string | null;
  round_name: string;
  school_a_id?: string | null;
  school_b_id?: string | null;
  scheduled_at?: string | null;
  venue_name?: string | null;
  status: string;
};

type MatchResult = {
  id?: string;
  match_id: string;
  score_a: number;
  score_b: number;
  winner_school_id?: string | null;
};

type EventResult = {
  id: string;
  event_id: string;
  entry_id: string;
  school_id: string;
  entry_name: string;
  rank?: number | null;
  performance_value?: number | null;
  performance_unit?: string | null;
  result_text?: string | null;
};

type Medal = {
  id: string;
  competition_id: string;
  event_id: string;
  school_id: string;
  medal_type: "gold" | "silver" | "bronze";
};

type Coach = { name: string; phone: string };
type AthleteInput = {
  prefix?: string;
  ign?: string; team_role?: string; play_position?: string;
  student_code: string | null;
  full_name: string;
  grade_level: string | null;
  gender: string | null;
};

type TabKey = "overview" | "submissions" | "schedule" | "schools" | "events" | "entries" | "matches" | "standings" | "medals" | "accounts";
type UserRole = { role: string; school_id?: string | null; competition_id?: string | null };

const DEMO_COMPETITION: Competition = {
  id: "demo-competition",
  name: "การแข่งขันกีฬากลุ่มมัธยมศึกษาจังหวัดพะเยา",
  academic_year: "2569",
  status: "draft",
};

const DEMO_SCHOOLS: School[] = [
  { id: "demo-school-a", school_code: "DEMO-A", name: "โรงเรียนตัวอย่าง A", district: "อำเภอตัวอย่าง", province: "พะเยา", status: "active" },
  { id: "demo-school-b", school_code: "DEMO-B", name: "โรงเรียนตัวอย่าง B", district: "อำเภอตัวอย่าง", province: "พะเยา", status: "active" },
  { id: "demo-school-c", school_code: "DEMO-C", name: "โรงเรียนตัวอย่าง C", district: "อำเภอตัวอย่าง", province: "พะเยา", status: "active" },
  { id: "demo-school-d", school_code: "DEMO-D", name: "โรงเรียนตัวอย่าง D", district: "อำเภอตัวอย่าง", province: "พะเยา", status: "active" },
];

const DEMO_EVENTS: SportEvent[] = [
  { id: "demo-event-football", competition_id: DEMO_COMPETITION.id, event_code: "FB-MJ", sport_name: "ฟุตบอลชาย ม.ต้น", event_type: "team", gender_rule: "ชาย", level_rule: "ม.ต้น", competition_format: "league", max_athletes_per_entry: 20, points_win: 3, points_draw: 1, points_loss: 0, status: "registration" },
  { id: "demo-event-volleyball", competition_id: DEMO_COMPETITION.id, event_code: "VB-FS", sport_name: "วอลเลย์บอลหญิง ม.ปลาย", event_type: "team", gender_rule: "หญิง", level_rule: "ม.ปลาย", competition_format: "knockout", max_athletes_per_entry: 12, points_win: 3, points_draw: 0, points_loss: 0, status: "registration" },
  { id: "demo-event-run", competition_id: DEMO_COMPETITION.id, event_code: "AT-100M", sport_name: "วิ่ง 100 เมตร ชาย ม.ต้น", event_type: "athletics", gender_rule: "ชาย", level_rule: "ม.ต้น", competition_format: "time", max_athletes_per_entry: 1, status: "scheduled" },
  { id: "demo-event-petanque", competition_id: DEMO_COMPETITION.id, event_code: "PT-MIX", sport_name: "เปตองคู่ผสม ม.ปลาย", event_type: "individual", gender_rule: "ผสม", level_rule: "ม.ปลาย", competition_format: "knockout", max_athletes_per_entry: 2, status: "registration" },
];

const DEMO_ENTRIES: Entry[] = [
  { id: "demo-entry-a", competition_id: DEMO_COMPETITION.id, event_id: "demo-event-football", school_id: "demo-school-a", entry_type: "team", entry_name: "ทีมฟุตบอลชาย", coach_name: "ครูผู้ฝึกสอน A", status: "approved", athlete_count: 18 },
  { id: "demo-entry-b", competition_id: DEMO_COMPETITION.id, event_id: "demo-event-football", school_id: "demo-school-b", entry_type: "team", entry_name: "ทีมฟุตบอลชาย", coach_name: "ครูผู้ฝึกสอน B", status: "approved", athlete_count: 18 },
  { id: "demo-entry-c", competition_id: DEMO_COMPETITION.id, event_id: "demo-event-football", school_id: "demo-school-c", entry_type: "team", entry_name: "ทีมฟุตบอลชาย", coach_name: "ครูผู้ฝึกสอน C", status: "submitted", athlete_count: 16 },
  { id: "demo-entry-d", competition_id: DEMO_COMPETITION.id, event_id: "demo-event-volleyball", school_id: "demo-school-a", entry_type: "team", entry_name: "ทีมวอลเลย์บอลหญิง", status: "approved", athlete_count: 10 },
  { id: "demo-entry-e", competition_id: DEMO_COMPETITION.id, event_id: "demo-event-volleyball", school_id: "demo-school-d", entry_type: "team", entry_name: "ทีมวอลเลย์บอลหญิง", status: "approved", athlete_count: 11 },
  { id: "demo-entry-run-a", competition_id: DEMO_COMPETITION.id, event_id: "demo-event-run", school_id: "demo-school-a", entry_type: "individual", entry_name: "นักกีฬาตัวอย่าง A", status: "approved", athlete_count: 1 },
  { id: "demo-entry-run-b", competition_id: DEMO_COMPETITION.id, event_id: "demo-event-run", school_id: "demo-school-b", entry_type: "individual", entry_name: "นักกีฬาตัวอย่าง B", status: "approved", athlete_count: 1 },
];

const DEMO_MATCHES: Match[] = [
  { id: "demo-match-1", competition_id: DEMO_COMPETITION.id, event_id: "demo-event-football", match_number: "FB-001", group_name: "สาย A", round_name: "รอบแบ่งกลุ่ม", school_a_id: "demo-school-a", school_b_id: "demo-school-b", status: "completed", venue_name: "สนามฟุตบอล" },
  { id: "demo-match-2", competition_id: DEMO_COMPETITION.id, event_id: "demo-event-football", match_number: "FB-002", group_name: "สาย A", round_name: "รอบแบ่งกลุ่ม", school_a_id: "demo-school-a", school_b_id: "demo-school-c", status: "scheduled", venue_name: "สนามฟุตบอล" },
  { id: "demo-match-3", competition_id: DEMO_COMPETITION.id, event_id: "demo-event-volleyball", match_number: "VB-001", group_name: "สาย B", round_name: "รอบรองชนะเลิศ", school_a_id: "demo-school-a", school_b_id: "demo-school-d", status: "scheduled", venue_name: "โรงยิม" },
];

const DEMO_RESULTS: MatchResult[] = [
  { match_id: "demo-match-1", score_a: 2, score_b: 1, winner_school_id: "demo-school-a" },
];

const DEMO_EVENT_RESULTS: EventResult[] = [
  { id: "demo-event-result-a", event_id: "demo-event-run", entry_id: "demo-entry-run-a", school_id: "demo-school-a", entry_name: "นักกีฬาตัวอย่าง A", rank: 1, performance_value: 12.45, performance_unit: "วินาที" },
  { id: "demo-event-result-b", event_id: "demo-event-run", entry_id: "demo-entry-run-b", school_id: "demo-school-b", entry_name: "นักกีฬาตัวอย่าง B", rank: 2, performance_value: 12.78, performance_unit: "วินาที" },
];

const DEMO_MEDALS: Medal[] = [
  { id: "demo-medal-1", competition_id: DEMO_COMPETITION.id, event_id: "demo-event-run", school_id: "demo-school-a", medal_type: "gold" },
  { id: "demo-medal-2", competition_id: DEMO_COMPETITION.id, event_id: "demo-event-run", school_id: "demo-school-b", medal_type: "silver" },
  { id: "demo-medal-3", competition_id: DEMO_COMPETITION.id, event_id: "demo-event-run", school_id: "demo-school-c", medal_type: "bronze" },
];

// Card-style sports navigation with large colourful icons.
const sportsMenuItem = "group relative flex min-h-[112px] w-full min-w-0 flex-col items-center justify-center gap-2 overflow-hidden rounded-2xl border border-slate-200 bg-gradient-to-b from-white to-slate-50 px-3 py-4 text-center shadow-sm transition-all duration-200 hover:-translate-y-1 hover:shadow-md focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-slate-900 active:scale-[0.99] motion-reduce:transform-none motion-reduce:transition-none";
const tabs: { key: TabKey; label: string; icon: (props: IconProps) => JSX.Element; iconClass: string; activeClass: string; badgeClass: string }[] = [
  { key: "overview", label: "หน้าหลัก", icon: HomeIcon, iconClass: "text-sky-600", activeClass: "border-sky-300 bg-sky-950 text-white shadow-[0_14px_28px_-18px_rgba(3,105,161,0.85)]", badgeClass: "bg-sky-100 text-sky-700 group-hover:bg-sky-200" },
  { key: "submissions", label: "ส่งข้อมูลโรงเรียน", icon: FileUploadIcon, iconClass: "text-rose-600", activeClass: "border-rose-300 bg-rose-950 text-white shadow-[0_14px_28px_-18px_rgba(190,24,93,0.85)]", badgeClass: "bg-rose-100 text-rose-700 group-hover:bg-rose-200" },
  { key: "schedule", label: "จัดการ / ดูโปรแกรม", icon: CalendarGearIcon, iconClass: "text-violet-600", activeClass: "border-violet-300 bg-violet-950 text-white shadow-[0_14px_28px_-18px_rgba(109,40,217,0.85)]", badgeClass: "bg-violet-100 text-violet-700 group-hover:bg-violet-200" },
  { key: "schools", label: "โรงเรียน", icon: SchoolIcon, iconClass: "text-cyan-700", activeClass: "border-cyan-300 bg-cyan-950 text-white shadow-[0_14px_28px_-18px_rgba(14,116,144,0.85)]", badgeClass: "bg-cyan-100 text-cyan-700 group-hover:bg-cyan-200" },
  { key: "events", label: "รายการแข่งขัน", icon: TrophyIcon, iconClass: "text-amber-600", activeClass: "border-amber-300 bg-amber-950 text-white shadow-[0_14px_28px_-18px_rgba(180,83,9,0.85)]", badgeClass: "bg-amber-100 text-amber-700 group-hover:bg-amber-200" },
  { key: "entries", label: "ลงทะเบียน", icon: ClipboardCheckIcon, iconClass: "text-blue-700", activeClass: "border-blue-300 bg-blue-950 text-white shadow-[0_14px_28px_-18px_rgba(29,78,216,0.85)]", badgeClass: "bg-blue-100 text-blue-700 group-hover:bg-blue-200" },
  { key: "matches", label: "โปรแกรม / ผล", icon: CalendarCheckIcon, iconClass: "text-indigo-700", activeClass: "border-indigo-300 bg-indigo-950 text-white shadow-[0_14px_28px_-18px_rgba(67,56,202,0.85)]", badgeClass: "bg-indigo-100 text-indigo-700 group-hover:bg-indigo-200" },
  { key: "standings", label: "ตารางคะแนน", icon: BarChartIcon, iconClass: "text-emerald-700", activeClass: "border-emerald-300 bg-emerald-950 text-white shadow-[0_14px_28px_-18px_rgba(4,120,87,0.85)]", badgeClass: "bg-emerald-100 text-emerald-700 group-hover:bg-emerald-200" },
  { key: "medals", label: "เหรียญรางวัล", icon: MedalIcon, iconClass: "text-orange-600", activeClass: "border-orange-300 bg-orange-950 text-white shadow-[0_14px_28px_-18px_rgba(194,65,12,0.85)]", badgeClass: "bg-orange-100 text-orange-700 group-hover:bg-orange-200" },
  { key: "accounts", label: "บัญชีโรงเรียน", icon: UserShieldIcon, iconClass: "text-fuchsia-700", activeClass: "border-fuchsia-300 bg-[#0f2e67] text-white shadow-[0_14px_28px_-18px_rgba(30,64,175,0.85)]", badgeClass: "bg-fuchsia-100 text-fuchsia-700 group-hover:bg-fuchsia-200" },
];

function makeId(prefix: string) {
  return `${prefix}-${typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : Date.now()}`;
}

function formatThaiDate(value?: string | null) {
  if (!value) return "ยังไม่กำหนด";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("th-TH", { dateStyle: "medium", timeStyle: "short" }).format(date);
}

function eventTypeLabel(value: string) {
  if (value === "athletics") return "กรีฑา";
  if (value === "individual") return "กีฬาเดี่ยว / คู่";
  return "กีฬาทีม";
}

function statusLabel(value: string) {
  const labels: Record<string, string> = {
    draft: "ฉบับร่าง",
    registration: "เปิดรับสมัคร",
    submitted: "ส่งข้อมูลแล้ว",
    approved: "อนุมัติแล้ว",
    rejected: "ส่งคืนให้แก้ไข",
    withdrawn: "ถอนรายการ",
    scheduled: "รอแข่งขัน",
    live: "กำลังแข่งขัน",
    completed: "เสร็จสิ้น",
    postponed: "เลื่อนการแข่งขัน",
    cancelled: "ยกเลิก",
    closed: "ปิดรับสมัคร",
    in_progress: "กำลังดำเนินการ",
  };
  return labels[value] || value || "-";
}

const namePrefixes: readonly string[] = ATHLETE_NAME_PREFIXES;
function editPlayerName(player: AthleteInput): AthleteInput {
  const prefix = namePrefixes.find(title => player.full_name.startsWith(title));
  const normalized = {...player,play_position:player.play_position === "Mid" ? "Midlane" : player.play_position};
  return prefix ? {...normalized,prefix,full_name:player.full_name.slice(prefix.length).trimStart()} : normalized;
}
function acceptsNewEntries(event: SportEvent) {
  return event.stage3_source == null || event.status === "registration";
}
const blankPlayer = (): AthleteInput => ({ student_code: "", full_name: "", grade_level: null, gender: null });
const isRov = (event?: SportEvent) => ["GS3-ES-SM", "GS3-ES-SF"].includes(event?.event_code || "");

function validateAthletes(event: SportEvent, athletes: AthleteInput[], individualBatch = false) {
  if (!athletes.length) return "กรุณากรอกรายชื่อนักกีฬาอย่างน้อย 1 คน";
  if (individualBatch && athletes.length > 100) return "นำเข้ากีฬาเดี่ยวได้ไม่เกิน 100 คนต่อครั้ง";
  if (!individualBatch && event.max_athletes_per_entry && athletes.length > event.max_athletes_per_entry) {
    return `รายการนี้รับนักกีฬาได้ไม่เกิน ${event.max_athletes_per_entry} คนต่อทีม`;
  }
  const duplicateCodes = athletes
    .map((athlete) => athlete.student_code)
    .filter((code): code is string => Boolean(code))
    .filter((code, index, all) => all.indexOf(code) !== index);
  if (duplicateCodes.length) return "พบรหัสนักเรียนซ้ำในรายชื่อชุดนี้";

  // The roster never requests gender or grade. Event rules remain visible to the
  // school for eligibility checks; they cannot be verified from names alone.
  return "";
}

export default function GroupSportsDashboard() {
  const [tab, setTab] = useState<TabKey>("overview");
  const [scheduleView, setScheduleView] = useState<"schedule" | "events">("schedule");
  const [competition, setCompetition] = useState<Competition | null>(null);
  const [schools, setSchools] = useState<School[]>([]);
  const [events, setEvents] = useState<SportEvent[]>([]);
  const [entries, setEntries] = useState<Entry[]>([]);
  const [matches, setMatches] = useState<Match[]>([]);
  const [results, setResults] = useState<MatchResult[]>([]);
  const [eventResults, setEventResults] = useState<EventResult[]>([]);
  const [medals, setMedals] = useState<Medal[]>([]);
  const [roles, setRoles] = useState<UserRole[]>([]);
  const [isAdmin, setIsAdmin] = useState(false);
  const [userEmail, setUserEmail] = useState("");
  const [isDemo, setIsDemo] = useState(false);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const [formOpen, setFormOpen] = useState(false);
  const [selectedEventId, setSelectedEventId] = useState("all");
  const [resultMatchId, setResultMatchId] = useState("");
  const [resultScoreA, setResultScoreA] = useState("0");
  const [resultScoreB, setResultScoreB] = useState("0");

  const [coaches,setCoaches] = useState<Coach[]>([{name:"",phone:""}]);
  const [players,setPlayers] = useState<AthleteInput[]>([blankPlayer()]);
  const [rosterImportBusy,setRosterImportBusy] = useState(false);
  const [rosterImportPreview,setRosterImportPreview] = useState<{fileName:string;athletes:ImportedAthlete[]} | null>(null);
  const [editEntry,setEditEntry] = useState<Entry | null>(null);
  const [eventChoice,setEventChoice] = useState("");
  const [detail,setDetail] = useState<{entry: Entry; players: AthleteInput[]} | null>(null);
  const [demoRosters,setDemoRosters] = useState<Record<string,AthleteInput[]>>({});
  const [schoolFilter,setSchoolFilter] = useState("");
  const [eventFilter,setEventFilter] = useState("");
  const [statusFilter,setStatusFilter] = useState("");
  const [reason,setReason] = useState("");
  const chosenEvent = events.find(e => e.id === eventChoice);
  const rosterAdmin = isDemo || roles.some(r => (r.role==="super_admin" && (!r.competition_id || r.competition_id===competition?.id)) || (r.role==="competition_admin" && r.competition_id===competition?.id));
  const canManageCompetition = isDemo || isAdmin || roles.some((role) => role.role === "competition_admin" && (!role.competition_id || role.competition_id === competition?.id));
  const canManageSchool = rosterAdmin || roles.some((role) => role.role === "school_manager" && (!role.competition_id || role.competition_id === competition?.id));
  const canRecordResults = isDemo || canManageCompetition || roles.some((role) => role.role === "referee" && (!role.competition_id || role.competition_id === competition?.id));
  const canManageAccounts = !isDemo && roles.some((role) => (role.role === "super_admin" && (!role.competition_id || role.competition_id === competition?.id)) || (role.role === "competition_admin" && role.competition_id === competition?.id));
  const entrySchools = rosterAdmin
    ? schools
    : schools.filter((school) => roles.some((role) => role.role === "school_manager" && role.school_id === school.id && (!role.competition_id || role.competition_id===competition?.id)));

  const loadData = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const { data: authData } = await supabase.auth.getUser();
      const user = authData.user;
      let profileRole = "";
      let roleRows: UserRole[] = [];
      if (user) {
        setUserEmail(user.app_metadata?.sports_school_account ? "บัญชีโรงเรียน" : user.email || "");
        const [profileResult, roleResult] = await Promise.all([
          supabase.from("profiles").select("role").eq("id", user.id).maybeSingle(),
          supabase.from("sports_user_roles").select("role, school_id, competition_id").eq("user_id", user.id).eq("is_active", true),
        ]);
        profileRole = String(profileResult.data?.role || "").toLowerCase();
        roleRows = (roleResult.data || []) as UserRole[];
      } else {
        setUserEmail("");
      }
      setIsAdmin(profileRole === "admin" || roleRows.some((role) => role.role === "super_admin"));
      setRoles(roleRows);

      const [competitionResult, schoolResult, eventResult, matchResult, medalResult, eventResultsResult] = await Promise.all([
        supabase.from("sports_competitions").select("*").eq("slug", SPORTS_COMPETITION_SLUG).maybeSingle(),
        supabase.from("sports_schools").select("*").order("name"),
        supabase.from("sports_events").select("*").order("sport_name"),
        supabase.from("sports_matches").select("*").order("scheduled_at", { ascending: true }),
        supabase.from("sports_medals").select("*"),
        supabase.from("sports_event_results").select("*"),
      ]);

      const publicErrors = [competitionResult.error, schoolResult.error, eventResult.error, matchResult.error, medalResult.error, eventResultsResult.error].filter(Boolean);
      const missingTable = publicErrors.some((item) => item?.code === "42P01" || item?.code === "PGRST205");
      if (missingTable) {
        setIsDemo(true);
        setCompetition(DEMO_COMPETITION);
        setSchools(DEMO_SCHOOLS);
        setEvents(DEMO_EVENTS);
        setEntries(DEMO_ENTRIES);
        setMatches(DEMO_MATCHES);
        setResults(DEMO_RESULTS);
        setEventResults(DEMO_EVENT_RESULTS);
        setMedals(DEMO_MEDALS);
        setNotice("กำลังแสดงข้อมูลตัวอย่าง เนื่องจากยังไม่ได้ติดตั้งฐานข้อมูลระบบกีฬากลุ่ม");
        return;
      }
      if (publicErrors.length) {
        throw new Error(publicErrors[0]?.message || "ไม่สามารถอ่านข้อมูลระบบกีฬากลุ่มได้");
      }

      setIsDemo(false);
      const activeCompetition = (competitionResult.data || null) as Competition | null;
      if (!activeCompetition) {
        throw new Error("ไม่พบการแข่งขันภูลังกาเกมส์ 2569 กรุณาตรวจสอบข้อมูลการแข่งขันใน Supabase");
      }
      setCompetition(activeCompetition);
      const allSchools = (schoolResult.data || []) as School[];
      setSchools(allSchools.filter((school) => school.status !== "inactive"));
      const allEvents = (eventResult.data || []) as SportEvent[];
      setEvents(allEvents.filter((item) => item.competition_id === activeCompetition.id));
      const allMatches = (matchResult.data || []) as Match[];
      setMatches(allMatches.filter((item) => item.competition_id === activeCompetition.id));
      const allMedals = (medalResult.data || []) as Medal[];
      setMedals(allMedals.filter((item) => item.competition_id === activeCompetition.id));
      const allEventResults = (eventResultsResult.data || []) as EventResult[];
      const activeEventIds = new Set(allEvents.filter((item) => !activeCompetition || item.competition_id === activeCompetition.id).map((item) => item.id));
      setEventResults(allEventResults.filter((item) => activeEventIds.has(item.event_id)));

      const matchIds = allMatches.map((item) => item.id);
      if (matchIds.length) {
        const resultQuery = await supabase.from("sports_match_results").select("*").in("match_id", matchIds);
        if (resultQuery.error && resultQuery.error.code !== "PGRST205") throw resultQuery.error;
        setResults((resultQuery.data || []) as MatchResult[]);
      } else {
        setResults([]);
      }

      if (user && (profileRole === "admin" || roleRows.length > 0)) {
        const entryQuery = await supabase.from("sports_entries").select("*").order("created_at", { ascending: false });
        if (!entryQuery.error) {
          const entryRows = (entryQuery.data || []) as Entry[];
          const athleteQuery = await supabase.from("sports_athletes").select("entry_id");
          const athleteCounts = new Map<string, number>();
          (athleteQuery.data || []).forEach((row: { entry_id: string }) => athleteCounts.set(row.entry_id, (athleteCounts.get(row.entry_id) || 0) + 1));
          const enrichedEntries = entryRows.map((item) => ({ ...item, athlete_count: athleteCounts.get(item.id) || 0 }));
          setEntries(activeCompetition ? enrichedEntries.filter((item) => item.competition_id === activeCompetition.id) : enrichedEntries);
        } else {
          setEntries([]);
        }
      } else {
        setEntries([]);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "เกิดข้อผิดพลาดในการโหลดข้อมูล");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadData();
  }, [loadData]);

  const completedMatches = useMemo(() => matches.filter((match) => match.status === "completed"), [matches]);
  const totalMedals = medals.length;
  const schoolEntries = entries.filter(e=>entrySchools.some(s=>s.id===e.school_id));
  const registrationRows = schoolEntries.filter(e=>(!schoolFilter||e.school_id===schoolFilter)&&(!eventFilter||e.event_id===eventFilter)&&(!statusFilter||e.status===statusFilter));
  const approvedEntries = schoolEntries.filter((entry) => entry.status === "approved").length;

  const schoolById = useMemo(() => new Map(schools.map((school) => [school.id, school])), [schools]);
  const eventById = useMemo(() => new Map(events.map((event) => [event.id, event])), [events]);
  const resultByMatch = useMemo(() => new Map(results.map((result) => [result.match_id, result])), [results]);

  const medalTable = useMemo(() => {
    const rows = schools.map((school) => {
      const schoolMedals = medals.filter((medal) => medal.school_id === school.id);
      return {
        school,
        gold: schoolMedals.filter((medal) => medal.medal_type === "gold").length,
        silver: schoolMedals.filter((medal) => medal.medal_type === "silver").length,
        bronze: schoolMedals.filter((medal) => medal.medal_type === "bronze").length,
        total: schoolMedals.length,
      };
    }).filter((row) => row.total > 0);
    return rows.sort((a, b) => b.gold - a.gold || b.silver - a.silver || b.bronze - a.bronze);
  }, [medals, schools]);

  const standings = useMemo(() => {
    const filteredEvents = selectedEventId === "all" ? events : events.filter((event) => event.id === selectedEventId);
    return filteredEvents.flatMap((event) => {
      const eventMatches = matches.filter((match) => match.event_id === event.id && match.status === "completed");
      const matchesByGroup = new Map<string, Match[]>();
      eventMatches.forEach((match) => {
        const groupName = match.group_name || "ไม่แบ่งสาย";
        matchesByGroup.set(groupName, [...(matchesByGroup.get(groupName) || []), match]);
      });
      return [...matchesByGroup.entries()].map(([groupName, groupMatches]) => {
        const table = new Map<string, { school: School; played: number; win: number; draw: number; loss: number; scored: number; conceded: number; points: number }>();
        groupMatches.forEach((match) => {
          const result = resultByMatch.get(match.id);
          if (!result || !match.school_a_id || !match.school_b_id) return;
          const schoolA = schoolById.get(match.school_a_id);
          const schoolB = schoolById.get(match.school_b_id);
          if (!schoolA || !schoolB) return;
          const rowA = table.get(schoolA.id) || { school: schoolA, played: 0, win: 0, draw: 0, loss: 0, scored: 0, conceded: 0, points: 0 };
          const rowB = table.get(schoolB.id) || { school: schoolB, played: 0, win: 0, draw: 0, loss: 0, scored: 0, conceded: 0, points: 0 };
          rowA.played += 1; rowB.played += 1;
          rowA.scored += Number(result.score_a); rowA.conceded += Number(result.score_b);
          rowB.scored += Number(result.score_b); rowB.conceded += Number(result.score_a);
          if (Number(result.score_a) > Number(result.score_b)) {
            rowA.win += 1; rowB.loss += 1; rowA.points += event.points_win ?? 3; rowB.points += event.points_loss ?? 0;
          } else if (Number(result.score_b) > Number(result.score_a)) {
            rowB.win += 1; rowA.loss += 1; rowB.points += event.points_win ?? 3; rowA.points += event.points_loss ?? 0;
          } else {
            rowA.draw += 1; rowB.draw += 1; rowA.points += event.points_draw ?? 1; rowB.points += event.points_draw ?? 1;
          }
          table.set(schoolA.id, rowA); table.set(schoolB.id, rowB);
        });
        const rows = [...table.values()].sort((a, b) => b.points - a.points || (b.scored - b.conceded) - (a.scored - a.conceded) || b.scored - a.scored);
        return { event, groupName, rows };
      }).filter((group) => group.rows.length > 0);
    });
  }, [events, matches, resultByMatch, schoolById, selectedEventId]);

  async function addSchool(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!(isDemo || isAdmin)) return;
    const form = new FormData(event.currentTarget);
    const name = String(form.get("name") || "").trim();
    const schoolCode = String(form.get("school_code") || "").trim();
    const district = String(form.get("district") || "").trim();
    if (!name) return setError("กรุณากรอกชื่อโรงเรียน");
    setBusy(true); setError("");
    try {
      let joinWarning = "";
      const payload = { name, school_code: schoolCode || null, district: district || null, province: "พะเยา", status: "active" };
      if (isDemo) {
        const newSchool: School = { id: makeId("demo-school"), ...payload };
        setSchools((current) => [...current, newSchool]);
      } else {
        const { data, error: insertError } = await supabase.from("sports_schools").insert(payload).select("*").single();
        if (insertError) throw insertError;
        const newSchool = data as School;
        setSchools((current) => [...current, newSchool]);
        if (competition) {
          const { error: joinError } = await supabase.from("sports_competition_schools").upsert(
            { competition_id: competition.id, school_id: newSchool.id, status: "registered" },
            { onConflict: "competition_id,school_id" },
          );
          if (joinError) joinWarning = "เพิ่มโรงเรียนแล้ว แต่ยังผูกโรงเรียนเข้ารายการแข่งขันไม่สำเร็จ: " + joinError.message;
        }
      }
      setNotice(joinWarning || (isDemo ? "เพิ่มโรงเรียนในโหมดสาธิตแล้ว (ข้อมูลจะไม่ถูกบันทึกลงฐานข้อมูล)" : "เพิ่มโรงเรียนเรียบร้อยแล้ว"));
      setFormOpen(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : "เพิ่มโรงเรียนไม่สำเร็จ");
    } finally { setBusy(false); }
  }

  async function addEvent(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!canManageCompetition || !competition) return;
    const form = new FormData(event.currentTarget);
    const sportName = String(form.get("sport_name") || "").trim();
    if (!sportName) return setError("กรุณากรอกชื่อรายการแข่งขัน");
    const payload = {
      competition_id: competition.id,
      event_code: String(form.get("event_code") || "").trim() || null,
      sport_name: sportName,
      event_type: String(form.get("event_type") || "team"),
      gender_rule: String(form.get("gender_rule") || "รวม"),
      level_rule: String(form.get("level_rule") || "ไม่จำกัด"),
      competition_format: String(form.get("competition_format") || "league"),
      max_athletes_per_entry: Number(form.get("max_athletes_per_entry") || 0) || null,
      points_win: Number(form.get("points_win") || 3),
      points_draw: Number(form.get("points_draw") || 1),
      points_loss: Number(form.get("points_loss") || 0),
      venue_name: String(form.get("venue_name") || "").trim() || null,
      status: "registration",
    };
    setBusy(true); setError("");
    try {
      if (isDemo) {
        setEvents((current) => [...current, { id: makeId("demo-event"), ...payload } as SportEvent]);
      } else {
        const { data, error: insertError } = await supabase.from("sports_events").insert(payload).select("*").single();
        if (insertError) throw insertError;
        setEvents((current) => [...current, data as SportEvent]);
      }
      setNotice(isDemo ? "เพิ่มรายการแข่งขันในโหมดสาธิตแล้ว" : "เพิ่มรายการแข่งขันเรียบร้อยแล้ว");
      setFormOpen(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : "เพิ่มรายการแข่งขันไม่สำเร็จ");
    } finally { setBusy(false); }
  }

  async function addEntry(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!canManageSchool || !competition) return;
    const form = new FormData(event.currentTarget);
    const eventId = String(form.get("event_id") || "");
    const schoolId = String(form.get("school_id") || "");
    const sportEvent = events.find((item) => item.id === eventId);
    const entryName = isRov(sportEvent) ? (editEntry?.entry_name || schools.find(s=>s.id===schoolId)?.name || "")
      : String(form.get("entry_name") || "").trim() || (sportEvent?.event_type !== "team" ? `${players[0]?.prefix || ""}${players[0]?.full_name.trim() || ""}` : "");
    if (!sportEvent || !schoolId || !entryName) return setError("กรุณาเลือกรายการแข่งขัน โรงเรียน และกรอกชื่อทีม/นักกีฬา");
    if (!editEntry && sportEvent.stage3_source != null && sportEvent.status !== "registration") return setError("รายการนี้ยังไม่เปิดรับสมัคร");
    const athletes = players.map(p=>({
      ...p,
      full_name:p.full_name.trim() ? (p.prefix || "") + p.full_name.trim() : "",
      student_code:p.student_code?.trim()||null,
      // No sports registration collects grade or gender.
      grade_level: null,
      gender: null,
    }));
    if (athletes.some(a=>!a.full_name)) return setError("กรุณากรอกชื่อผู้เล่นทุกแถว");
    if (isRov(sportEvent) && (athletes.length<5 || athletes.length>7)) return setError("RoV ต้องมีผู้เล่นหลัก 5 คน และสามารถเพิ่มตัวสำรองได้อีกไม่เกิน 2 คน (ไม่บังคับ)");
    if (isRov(sportEvent)) {
      const reserveCount = athletes.filter(a=>a.team_role==="ตัวสำรอง").length;
      const invalidRole = athletes.some(a=>!["หัวหน้าทีม","ตัวจริง","ตัวสำรอง"].includes(a.team_role||""));
      if (athletes.filter(a=>a.team_role==="หัวหน้าทีม").length!==1 ||
          athletes.filter(a=>a.team_role==="ตัวจริง").length!==4 ||
          reserveCount>2 || invalidRole)
        return setError("กรุณาระบุหัวหน้าทีม 1 คน ตัวจริงอีก 4 คน และตัวสำรองไม่เกิน 2 คน (ไม่บังคับ)");
      if (!coaches.length) return setError("กรุณาเพิ่มครูผู้ควบคุมทีมอย่างน้อย 1 คน");
      if (coaches.some(c=>!c.name.trim() || !/^\+?\d{9,15}$/.test(c.phone.replace(/[ ()-]/g,""))))
        return setError("กรุณากรอกชื่อและเบอร์โทรศัพท์ครูทุกคนให้ครบ");
    }
    const individualBatch = !editEntry && supportsIndividualBatch(sportEvent) && athletes.length > 1;
    const validationMessage = validateAthletes(sportEvent, athletes, individualBatch);
    if (validationMessage) return setError(validationMessage);
    const payload = {
      competition_id: competition.id,
      event_id: eventId,
      school_id: schoolId,
      entry_type: sportEvent.event_type === "team" ? "team" : "individual",
      entry_name: entryName,
      coach_name: isRov(sportEvent)?coaches[0].name.trim():String(form.get("coach_name") || "").trim() || null,
      status: "submitted",
    };
    setBusy(true); setError("");
    try {
      const assistant = String(form.get("assistant_coach") || "").trim();
      let id = editEntry?.id;
      let batchSaved: Entry[] = [];
      if (isDemo) {
        if (individualBatch) {
          const newRosters: Record<string, AthleteInput[]> = {};
          batchSaved = athletes.map((athlete) => {
            const newId = makeId("demo-entry");
            newRosters[newId] = [athlete];
            return {...payload,id:newId,entry_name:athlete.full_name,assistant_coach:assistant,athlete_count:1} as Entry;
          });
          setDemoRosters(prev=>({...prev,...newRosters}));
        } else {
          id = id || makeId("demo-entry");
          setDemoRosters(prev=>({...prev,[id!]:athletes}));
        }
      } else if (individualBatch) {
        const result = await supabase.rpc("sports_register_individual_batch",{
          p_event:eventId,p_school:schoolId,p_coach:payload.coach_name,p_players:athletes
        });
        if (result.error) throw new Error(result.error.message);
        const records = result.data as {id:string;entry_name:string}[];
        if (!Array.isArray(records) || records.length !== athletes.length) throw new Error("ผลการนำเข้าจากฐานข้อมูลไม่ครบ กรุณาตรวจสอบใบสมัคร");
        batchSaved = records.map(row=>({...payload,id:row.id,entry_name:row.entry_name,assistant_coach:assistant,athlete_count:1} as Entry));
      } else {
        const result = await supabase.rpc("sports_register_roster",{p_entry:id||null,p_event:eventId,p_school:schoolId,p_name:entryName,p_coach:payload.coach_name,p_assistant:assistant||null,p_players:athletes,p_coaches:isRov(sportEvent)?coaches:null});
        if (result.error) throw new Error(result.error.message);
        id = result.data as string;
      }
      if (individualBatch) {
        setEntries(current=>[...batchSaved,...current]);
      } else {
        const saved = {...payload,id:id!,assistant_coach:assistant,coaches:isRov(sportEvent)?coaches:undefined,athlete_count:athletes.length} as Entry;
        setEntries(current=>[saved,...current.filter(row=>row.id!==id)]);
      }
      setEditEntry(null); setDetail(null); setRosterImportPreview(null);
      setNotice(individualBatch ? `${isDemo ? "นำเข้าในโหมดสาธิต" : "ส่งข้อมูลลงทะเบียน"}กีฬาเดี่ยว ${batchSaved.length} คน (แยกใบสมัครรายคน) เรียบร้อยแล้ว` : isDemo ? "บันทึกการลงทะเบียนในโหมดสาธิตแล้ว" : "ส่งข้อมูลลงทะเบียนเรียบร้อยแล้ว");
      setFormOpen(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : "ลงทะเบียนไม่สำเร็จ");
    } finally { setBusy(false); }
  }

  async function openRoster(entry: Entry, edit = false) {
    setBusy(true);setError("");setDetail(null);setReason("");setFormOpen(false);
    try {
      let list=demoRosters[entry.id]||[];
      let staff=entry.coaches || [entry.coach_name,entry.assistant_coach].filter(Boolean).map(name=>({name:name!,phone:""}));
      if (!isDemo) {
        const {data,error}=await supabase.rpc("sports_roster_details",{p_entry:entry.id,p_team:null});
        if (error || !data) throw new Error(error?.message || "ไม่มีสิทธิ์ดูรายชื่อชุดนี้");
        list=data.players as AthleteInput[];staff=data.coaches || staff;
      }
      if(edit) {
        setCoaches(staff.length?staff:[{name:"",phone:""}]);setEditEntry(entry);setEventChoice(entry.event_id);setPlayers(list.length?list.map(editPlayerName):[blankPlayer()]);setRosterImportPreview(null);setFormOpen(true);
        window.scrollTo({top:0,behavior:"smooth"});
      } else setDetail({entry:{...entry,coaches:staff},players:list});
    } catch(err) {setError(err instanceof Error?err.message:"เปิดรายชื่อไม่สำเร็จ");}
    finally {setBusy(false);}
  }

  async function updateEntryStatus(entryId: string, status: "approved" | "rejected") {
    if (!rosterAdmin || busy) return;
    if (status==="rejected" && !reason.trim()) return setError("ระบุเหตุผลก่อนส่งคืน");
    setBusy(true); setError("");
    try {
      if (!isDemo) {
        const {error} = await supabase.rpc("sports_review_roster",{p_entry:entryId,p_status:status,p_reason:reason});
        if(error) throw new Error(error.message);
      }
      setEntries(current=>current.map(e=>e.id===entryId?{...e,status,return_reason:status==="rejected"?reason:""}:e));
      setDetail(null);setReason("");
      setNotice(isDemo ? "ปรับสถานะการลงทะเบียนในโหมดสาธิตแล้ว" : "ปรับสถานะการลงทะเบียนเรียบร้อยแล้ว");
    } catch (err) {
      setError(err instanceof Error ? err.message : "ปรับสถานะไม่สำเร็จ");
    } finally { setBusy(false); }
  }

  async function addMatch(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!canManageCompetition || !competition) return;
    const form = new FormData(event.currentTarget);
    const eventId = String(form.get("event_id") || "");
    const schoolAId = String(form.get("school_a_id") || "");
    const schoolBId = String(form.get("school_b_id") || "");
    if (!eventId || !schoolAId || !schoolBId) return setError("กรุณาเลือกรายการแข่งขันและโรงเรียนทั้งสองฝ่าย");
    if (schoolAId === schoolBId) return setError("โรงเรียนทั้งสองฝ่ายต้องไม่ซ้ำกัน");
    const dateTime = String(form.get("scheduled_at") || "");
    const payload = {
      competition_id: competition.id,
      event_id: eventId,
      match_number: String(form.get("match_number") || "").trim() || null,
      group_name: String(form.get("group_name") || "").trim() || null,
      round_name: String(form.get("round_name") || "รอบแบ่งกลุ่ม"),
      school_a_id: schoolAId,
      school_b_id: schoolBId,
      scheduled_at: dateTime ? new Date(dateTime).toISOString() : null,
      venue_name: String(form.get("venue_name") || "").trim() || null,
      status: "scheduled",
    };
    setBusy(true); setError("");
    try {
      if (isDemo) {
        setMatches((current) => [...current, { id: makeId("demo-match"), ...payload } as Match]);
      } else {
        const { data, error: insertError } = await supabase.from("sports_matches").insert(payload).select("*").single();
        if (insertError) throw insertError;
        setMatches((current) => [...current, data as Match]);
      }
      setNotice(isDemo ? "เพิ่มโปรแกรมแข่งขันในโหมดสาธิตแล้ว" : "เพิ่มโปรแกรมแข่งขันเรียบร้อยแล้ว");
      setFormOpen(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : "เพิ่มโปรแกรมแข่งขันไม่สำเร็จ");
    } finally { setBusy(false); }
  }

  async function saveMatchResult(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!canRecordResults) return;
    const match = matches.find((item) => item.id === resultMatchId);
    if (!match) return setError("ไม่พบรายการแข่งขันที่เลือก");
    const scoreA = Number(resultScoreA);
    const scoreB = Number(resultScoreB);
    if (!Number.isFinite(scoreA) || !Number.isFinite(scoreB) || scoreA < 0 || scoreB < 0) return setError("กรุณากรอกคะแนนเป็นตัวเลขตั้งแต่ 0 ขึ้นไป");
    const winnerSchoolId = scoreA === scoreB ? null : scoreA > scoreB ? match.school_a_id || null : match.school_b_id || null;
    setBusy(true); setError("");
    try {
      const resultPayload = { match_id: match.id, score_a: scoreA, score_b: scoreB, winner_school_id: winnerSchoolId, recorded_at: new Date().toISOString() };
      if (isDemo) {
        setResults((current) => [...current.filter((item) => item.match_id !== match.id), resultPayload]);
        setMatches((current) => current.map((item) => item.id === match.id ? { ...item, status: "completed" } : item));
      } else {
        const { error: resultError } = await supabase.from("sports_match_results").upsert(resultPayload, { onConflict: "match_id" });
        if (resultError) throw resultError;
        const { error: matchError } = await supabase.from("sports_matches").update({ status: "completed" }).eq("id", match.id);
        if (matchError) throw matchError;
        setResults((current) => [...current.filter((item) => item.match_id !== match.id), resultPayload]);
        setMatches((current) => current.map((item) => item.id === match.id ? { ...item, status: "completed" } : item));
      }
      setNotice(isDemo ? "บันทึกผลการแข่งขันในโหมดสาธิตแล้ว" : "บันทึกผลการแข่งขันและอัปเดตสถานะแล้ว");
      setResultMatchId(""); setResultScoreA("0"); setResultScoreB("0");
    } catch (err) {
      setError(err instanceof Error ? err.message : "บันทึกผลการแข่งขันไม่สำเร็จ");
    } finally { setBusy(false); }
  }

  async function saveEventResult(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!canRecordResults) return;
    const form = new FormData(event.currentTarget);
    const eventId = String(form.get("event_id") || "");
    const entryId = String(form.get("entry_id") || "");
    const entry = entries.find((item) => item.id === entryId);
    if (!eventId || !entry || entry.event_id !== eventId || entry.status !== "approved") return setError("กรุณาเลือกรายการแข่งขันและผู้เข้าแข่งขันที่ได้รับอนุมัติแล้วให้ตรงกัน");
    const rankValue = String(form.get("rank") || "").trim();
    const performanceValue = String(form.get("performance_value") || "").trim();
    const payload = {
      event_id: eventId,
      entry_id: entryId,
      school_id: entry.school_id,
      entry_name: entry.entry_name,
      rank: rankValue ? Number(rankValue) : null,
      performance_value: performanceValue ? Number(performanceValue) : null,
      performance_unit: String(form.get("performance_unit") || "").trim() || null,
      result_text: String(form.get("result_text") || "").trim() || null,
      recorded_at: new Date().toISOString(),
    };
    if ((payload.rank !== null && (!Number.isInteger(payload.rank) || payload.rank < 1)) || (payload.performance_value !== null && !Number.isFinite(payload.performance_value))) {
      return setError("อันดับต้องเป็นจำนวนเต็มบวก และสถิติต้องเป็นตัวเลข");
    }
    setBusy(true); setError("");
    try {
      if (isDemo) {
        setEventResults((current) => [...current.filter((item) => !(item.event_id === eventId && item.entry_id === entryId)), { id: makeId("demo-event-result"), ...payload } as EventResult]);
      } else {
        const { data, error: resultError } = await supabase.from("sports_event_results").upsert(payload, { onConflict: "event_id,entry_id" }).select("*").single();
        if (resultError) throw resultError;
        setEventResults((current) => [...current.filter((item) => !(item.event_id === eventId && item.entry_id === entryId)), data as EventResult]);
      }
      setNotice(isDemo ? "บันทึกผลรายบุคคลในโหมดสาธิตแล้ว" : "บันทึกผลรายบุคคลเรียบร้อยแล้ว");
      setFormOpen(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : "บันทึกผลรายบุคคลไม่สำเร็จ");
    } finally { setBusy(false); }
  }

  async function addMedal(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!canManageCompetition || !competition) return;
    const form = new FormData(event.currentTarget);
    const eventId = String(form.get("event_id") || "");
    const schoolId = String(form.get("school_id") || "");
    const medalType = String(form.get("medal_type") || "gold") as Medal["medal_type"];
    if (!eventId || !schoolId) return setError("กรุณาเลือกรายการแข่งขันและโรงเรียน");
    setBusy(true); setError("");
    try {
      if (isDemo) {
        setMedals((current) => [...current, { id: makeId("demo-medal"), competition_id: competition.id, event_id: eventId, school_id: schoolId, medal_type: medalType }]);
      } else {
        const { data, error: insertError } = await supabase.from("sports_medals").insert({ competition_id: competition.id, event_id: eventId, school_id: schoolId, medal_type: medalType }).select("*").single();
        if (insertError) throw insertError;
        setMedals((current) => [...current, data as Medal]);
      }
      setNotice(isDemo ? "เพิ่มเหรียญรางวัลในโหมดสาธิตแล้ว" : "บันทึกเหรียญรางวัลเรียบร้อยแล้ว");
      setFormOpen(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : "บันทึกเหรียญรางวัลไม่สำเร็จ");
    } finally { setBusy(false); }
  }

  const renderForm = () => {
    if (!formOpen) return null;
    const formShell = "rounded-2xl border border-blue-100 bg-blue-50/60 p-4 md:p-5";
    const labelClass = "mb-1 block text-xs font-bold text-slate-600";
    const inputClass = "w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-800 outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-100";
    const close = () => setFormOpen(false);

    if (tab === "schools" && (isDemo || isAdmin)) return (
      <form className={formShell} onSubmit={addSchool}>
        <div className="mb-4 flex items-center justify-between"><h3 className="font-bold text-slate-900">เพิ่มโรงเรียนเข้าร่วมการแข่งขัน</h3><button type="button" onClick={close} className="text-sm text-slate-500">ปิด ✕</button></div>
        <div className="grid gap-3 md:grid-cols-3">
          <label><span className={labelClass}>ชื่อโรงเรียน *</span><input name="name" required className={inputClass} placeholder="ชื่อโรงเรียน" /></label>
          <label><span className={labelClass}>รหัสโรงเรียน</span><input name="school_code" className={inputClass} placeholder="เช่น PY001" /></label>
          <label><span className={labelClass}>อำเภอ</span><input name="district" className={inputClass} placeholder="อำเภอ" /></label>
        </div>
        <div className="mt-4 flex justify-end"><button disabled={busy} className="rounded-xl bg-blue-700 px-5 py-2.5 text-sm font-bold text-white disabled:opacity-50">{busy ? "กำลังบันทึก..." : "บันทึกโรงเรียน"}</button></div>
      </form>
    );

    if (tab === "events" && canManageCompetition) return (
      <form className={formShell} onSubmit={addEvent}>
        <div className="mb-4 flex items-center justify-between"><h3 className="font-bold text-slate-900">เพิ่มรายการแข่งขัน</h3><button type="button" onClick={close} className="text-sm text-slate-500">ปิด ✕</button></div>
        <div className="grid gap-3 md:grid-cols-3">
          <label><span className={labelClass}>ชื่อรายการแข่งขัน *</span><input name="sport_name" required className={inputClass} placeholder="เช่น ฟุตบอลชาย ม.ต้น" /></label>
          <label><span className={labelClass}>รหัสรายการ</span><input name="event_code" className={inputClass} placeholder="เช่น FB-MJ" /></label>
          <label><span className={labelClass}>ประเภท</span><select name="event_type" className={inputClass}><option value="team">กีฬาทีม</option><option value="individual">กีฬาเดี่ยว / คู่</option><option value="athletics">กรีฑา</option></select></label>
          <label><span className={labelClass}>เพศ</span><select name="gender_rule" className={inputClass}><option>รวม</option><option>ชาย</option><option>หญิง</option><option>ผสม</option></select></label>
          <label><span className={labelClass}>รุ่น / ระดับชั้น</span><select name="level_rule" className={inputClass}><option>ไม่จำกัด</option><option>ม.ต้น</option><option>ม.ปลาย</option><option>ม.1</option><option>ม.2</option><option>ม.3</option><option>ม.4</option><option>ม.5</option><option>ม.6</option></select></label>
          <label><span className={labelClass}>รูปแบบแข่งขัน</span><select name="competition_format" className={inputClass}><option value="league">แบ่งสาย / พบกันหมด</option><option value="knockout">แพ้คัดออก</option><option value="time">จับเวลา</option><option value="distance">วัดระยะ</option><option value="points">สะสมคะแนน</option><option value="manual">กำหนดผลโดยกรรมการ</option></select></label>
          <label><span className={labelClass}>จำนวนนักกีฬาสูงสุดต่อทีม</span><input name="max_athletes_per_entry" type="number" min="1" className={inputClass} placeholder="ไม่จำกัด" /></label>
          <label><span className={labelClass}>คะแนนชนะ</span><input name="points_win" type="number" min="0" defaultValue="3" className={inputClass} /></label>
          <label><span className={labelClass}>คะแนนเสมอ / แพ้</span><div className="flex gap-2"><input name="points_draw" type="number" min="0" defaultValue="1" className={inputClass} /><input name="points_loss" type="number" min="0" defaultValue="0" className={inputClass} /></div></label>
          <label className="md:col-span-3"><span className={labelClass}>สนามแข่งขัน (ถ้ากำหนดแล้ว)</span><input name="venue_name" className={inputClass} placeholder="ชื่อสนาม" /></label>
        </div>
        <div className="mt-4 flex justify-end"><button disabled={busy} className="rounded-xl bg-blue-700 px-5 py-2.5 text-sm font-bold text-white disabled:opacity-50">{busy ? "กำลังบันทึก..." : "บันทึกรายการแข่งขัน"}</button></div>
      </form>
    );

    if (tab === "entries" && canManageSchool) return (
      <form key={editEntry?.id || "new-roster"} className={formShell} onSubmit={addEntry}>
        <div className="mb-4 flex items-center justify-between"><h3 className="font-bold text-slate-900">ลงทะเบียนทีม / นักกีฬา</h3><button type="button" onClick={close} className="text-sm text-slate-500">ปิด ✕</button></div>
        <div className="grid gap-3 md:grid-cols-2">
          <label><span className={labelClass}>รายการแข่งขัน *</span><select name="event_id" required disabled={rosterImportBusy} className={inputClass} value={eventChoice} onChange={e=>{
            const id=e.target.value;
            setRosterImportPreview(null);
            // Separate competitions should never inherit another event's roster.
            if (id !== eventChoice && !editEntry) {
              setPlayers(isRov(events.find(item=>item.id===id))
                ? Array.from({length:5},(_,i)=>({...blankPlayer(),team_role:i===0?"หัวหน้าทีม":"ตัวจริง"}))
                : [blankPlayer()]);
            }
            setEventChoice(id);
          }}><option value="" disabled>เลือกรายการแข่งขัน</option>{events.filter(item => !editEntry || item.id===editEntry.event_id).map(item => <option key={item.id} value={item.id}>{item.sport_name}{!acceptsNewEntries(item) ? ` · ${statusLabel(item.status)}` : ""}</option>)}</select></label>
          {!events.length && <p role="status" className="rounded-xl bg-amber-50 p-3 text-sm text-amber-900">ยังไม่พบรายการแข่งขันของภูลังกาเกมส์ 2569 ในฐานข้อมูล กรุณาตรวจสอบการนำเข้ารายการแข่งขันและรหัสการแข่งขัน (slug)</p>}
          <label><span className={labelClass}>โรงเรียน *</span><select name="school_id" required className={inputClass} defaultValue={editEntry?.school_id||(entrySchools.length===1?entrySchools[0].id:"")}><option value="" disabled>เลือกโรงเรียน</option>{entrySchools.filter(s=>!editEntry||s.id===editEntry.school_id).map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label>
          {chosenEvent && !editEntry && !acceptsNewEntries(chosenEvent) && <div className="rounded-xl bg-amber-50 p-3 text-sm text-amber-900 md:col-span-2">
            รายการนี้ยังไม่เปิดรับสมัคร {rosterAdmin && <button type="button" onClick={() => { setScheduleView("events"); setTab("schedule"); setFormOpen(false); }} className="font-bold underline">ไปที่จัดการ / ดูโปรแกรม → รายการแข่งขัน เพื่อเปลี่ยนสถานะเป็น “เปิดรับสมัคร”</button>}
          </div>}
          {(!chosenEvent || isRov(chosenEvent)) ? <div className="space-y-2 md:col-span-2">
            {coaches.map((coach,i)=><div key={i} className="grid items-end gap-2 md:grid-cols-[1fr_1fr_auto]">
              <label><span className={labelClass}>ครูผู้ควบคุมทีม คนที่ {i+1} *</span><input className={inputClass} required value={coach.name} onChange={e=>setCoaches(rows=>rows.map((c,j)=>i===j?{...c,name:e.target.value}:c))}/></label>
              <label><span className={labelClass}>เบอร์โทรศัพท์ *</span><input className={inputClass} type="tel" required value={coach.phone} onChange={e=>setCoaches(rows=>rows.map((c,j)=>i===j?{...c,phone:e.target.value}:c))}/></label>
              <button type="button" disabled={coaches.length<=1} title={coaches.length<=1?"ต้องมีครูผู้ควบคุมทีมอย่างน้อย 1 คน":"ลบครูผู้ควบคุมทีมคนนี้"} className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm font-bold text-red-700 disabled:cursor-not-allowed disabled:opacity-40" onClick={()=>setCoaches(rows=>rows.length>1?rows.filter((_,j)=>i!==j):rows)}>ลบครูคนที่ {i+1}</button>
            </div>)}
            <button type="button" className="rounded-lg bg-blue-50 p-2 font-bold text-blue-800" onClick={()=>setCoaches(rows=>[...rows,{name:"",phone:""}])}>＋ เพิ่มครูผู้ควบคุมทีม</button>
          </div> : <>
          <label><span className={labelClass}>ชื่อทีม / ชื่อนักกีฬา *</span><input name="entry_name" defaultValue={editEntry?.entry_name} required={chosenEvent?.event_type === "team"} className={inputClass} placeholder={chosenEvent?.event_type === "team" ? "ชื่อทีม" : "กีฬาเดี่ยว: ใช้ชื่อนักกีฬาคนแรกอัตโนมัติ"} /></label>
          <label><span className={labelClass}>ครูผู้ควบคุมทีม</span><input name="coach_name" defaultValue={editEntry?.coach_name||""} className={inputClass} placeholder="ชื่อครูผู้ควบคุม" /></label>
          </>}
        </div>
        <div className="my-4 flex items-center justify-between"><strong>รายชื่อนักกีฬา · {players.filter(p=>p.full_name.trim()).length} คน {isRov(chosenEvent)?"(ตัวจริง 5 คน · ตัวสำรองเพิ่มได้ 0–2 คน ไม่บังคับ)":chosenEvent && supportsIndividualBatch(chosenEvent)?"(แยกใบสมัครคนละ 1 คน สูงสุด 100 คน/ครั้ง)":chosenEvent?.max_athletes_per_entry?`/ ${chosenEvent.max_athletes_per_entry} คน`:""}</strong>
        <button type="button" className="rounded-lg bg-blue-50 p-2 font-bold text-blue-800" disabled={isRov(chosenEvent)?players.length>=7:chosenEvent&&supportsIndividualBatch(chosenEvent)?players.length>=100:!!chosenEvent?.max_athletes_per_entry&&players.length>=chosenEvent.max_athletes_per_entry} onClick={()=>setPlayers(rows=>[...rows,{...blankPlayer(),team_role:isRov(chosenEvent)?"ตัวสำรอง":undefined}])}>＋ เพิ่มนักกีฬา</button></div>
        <div className="mb-4 rounded-2xl border border-sky-200 bg-gradient-to-br from-sky-50 via-white to-emerald-50 p-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="font-black text-slate-800">นำเข้ารายชื่อนักกีฬาจาก Excel</p>
              <p className="mt-1 text-xs text-slate-600">1. เลือกรายการแข่งขัน  2. ดาวน์โหลดเทมเพลตเฉพาะรายการ  3. กรอกชื่อใน Excel  4. อัปโหลดและตรวจสอบ</p>
            </div>
            <button type="button" disabled={!chosenEvent || busy || rosterImportBusy} onClick={() => {
              if (!chosenEvent) return;
              setError("");
              void downloadRosterTemplate(chosenEvent).catch((err:unknown)=>setError(err instanceof Error ? err.message : "ดาวน์โหลดเทมเพลตไม่สำเร็จ"));
            }} className="rounded-xl bg-emerald-600 px-4 py-2.5 text-sm font-bold text-white shadow-sm transition hover:bg-emerald-700 disabled:cursor-not-allowed disabled:opacity-50">
              ↓ ดาวน์โหลดเทมเพลต Excel
            </button>
          </div>
          <div className="mt-3 flex flex-col gap-2 sm:flex-row sm:items-center">
            <label className="block flex-1 text-sm font-semibold text-slate-700">อัปโหลดไฟล์รายชื่อนักกีฬา (.xlsx, .xls)
              <input key={eventChoice} type="file" accept=".xlsx,.xls" disabled={!chosenEvent || busy || rosterImportBusy} className="mt-1 block w-full cursor-pointer rounded-xl border border-sky-200 bg-white p-2.5 text-xs file:mr-3 file:rounded-lg file:border-0 file:bg-blue-100 file:px-3 file:py-2 file:font-bold file:text-blue-800 disabled:opacity-50" onChange={(ev) => {
                const file = ev.currentTarget.files?.[0];
                ev.currentTarget.value = ""; // Permit selecting the same file after correction.
                if (!file || !chosenEvent) return;
                setRosterImportPreview(null);
                setRosterImportBusy(true); setError("");
                void readRosterExcel(file,chosenEvent).then(athletes=>{
                  setRosterImportPreview({fileName:file.name,athletes});
                }).catch((err:unknown)=>setError(err instanceof Error ? err.message : "อ่านไฟล์ Excel ไม่สำเร็จ"))
                  .finally(()=>setRosterImportBusy(false));
              }}/>
            </label>
            <p className="text-xs text-slate-500">รองรับไฟล์ไม่เกิน 5 MB · ไม่รวมข้อมูลชั้นและเพศ · ยังไม่บันทึกลงฐานข้อมูล</p>
          </div>
          {rosterImportBusy && <p role="status" className="mt-3 text-sm font-semibold text-blue-700">กำลังตรวจสอบรายชื่อในไฟล์...</p>}
          {rosterImportPreview && <div className="mt-4 rounded-xl border border-emerald-200 bg-white p-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="text-sm font-black text-emerald-800">พบ {rosterImportPreview.athletes.length} คน · {rosterImportPreview.fileName}</p>
              <div className="flex gap-2">
                <button type="button" className="rounded-lg border border-slate-200 px-3 py-2 text-xs font-bold text-slate-600" onClick={()=>setRosterImportPreview(null)}>ยกเลิก</button>
                <button type="button" disabled={busy} className="rounded-lg bg-blue-700 px-3 py-2 text-xs font-bold text-white disabled:opacity-50" onClick={()=>{
                  setPlayers(rosterImportPreview.athletes);
                  setRosterImportPreview(null);
                  setNotice("นำเข้ารายชื่อนักกีฬาในแบบฟอร์มแล้ว กรุณาตรวจสอบอีกครั้งและกดส่งข้อมูลลงทะเบียนเพื่อบันทึก");
                }}>ใช้รายชื่อ {rosterImportPreview.athletes.length} คนแทนรายชื่อในฟอร์ม</button>
              </div>
            </div>
            <div className="mt-3 max-h-52 overflow-auto rounded-lg border border-slate-100">
              <table className="w-full text-left text-xs"><thead className="sticky top-0 bg-slate-100"><tr><th className="p-2">ลำดับ</th><th className="p-2">รหัสนักเรียน</th><th className="p-2">ชื่อ–สกุล</th>{isRov(chosenEvent)&&<th className="p-2">บทบาท / IGN</th>}</tr></thead>
                <tbody>{rosterImportPreview.athletes.map((athlete,i)=><tr key={i} className="border-t border-slate-100"><td className="p-2">{i+1}</td><td className="p-2">{athlete.student_code||"-"}</td><td className="p-2">{athlete.prefix}{athlete.full_name}</td>{isRov(chosenEvent)&&<td className="p-2">{athlete.team_role} · {athlete.ign}</td>}</tr>)}</tbody></table>
            </div>
            <p className="mt-2 text-xs text-amber-800">การยืนยันจะเปลี่ยนเฉพาะรายชื่อนักกีฬาในแบบฟอร์ม ไม่เปลี่ยนโรงเรียน รายการแข่งขัน หรือครูผู้ควบคุมทีม</p>
          </div>}
          {chosenEvent && <p className="mt-3 text-xs text-amber-800">หมายเหตุ: โรงเรียนต้องตรวจสอบคุณสมบัตินักกีฬาให้ตรงตามประเภท {chosenEvent.gender_rule} / รุ่น {chosenEvent.level_rule} ก่อนส่งข้อมูล</p>}
        </div>
        {players.map((player,i)=><div key={i} className="mb-2 rounded-xl bg-slate-50 p-3">
          <div className="grid items-end gap-3 sm:grid-cols-[auto_minmax(120px,1fr)_minmax(0,3fr)]">
            <strong className="pb-2">คนที่ {i+1}</strong>
            <label className="text-xs">รหัสนักเรียน<input className={inputClass} value={player.student_code||""} onChange={e=>setPlayers(rows=>rows.map((p,j)=>j===i?{...p,student_code:e.target.value}:p))}/></label>
            <div className="grid grid-cols-[minmax(120px,1fr)_minmax(0,2fr)] items-end gap-2">
              <label className="text-xs">คำนำหน้าชื่อ *<select required className={inputClass} value={player.prefix||""} onChange={e=>setPlayers(rows=>rows.map((p,j)=>j===i?{...p,prefix:e.target.value}:p))}><option value="">เลือกคำนำหน้า</option>{namePrefixes.map(title=><option key={title}>{title}</option>)}</select></label>
              <label className="text-xs">ชื่อ–สกุล *<input className={inputClass} required value={player.full_name||""} onChange={e=>setPlayers(rows=>rows.map((p,j)=>j===i?{...p,full_name:e.target.value}:p))}/></label>
            </div>
          </div>
          {isRov(chosenEvent) && <div className="grid gap-2 sm:col-span-full sm:grid-cols-3">
            <label className="text-xs">บทบาทในทีม *<select className={inputClass} required value={player.team_role||""} onChange={e=>setPlayers(rows=>rows.map((p,j)=>j===i?{...p,team_role:e.target.value}:p))}><option value="">เลือกบทบาท</option>{["หัวหน้าทีม","ตัวจริง","ตัวสำรอง"].map(r=><option key={r}>{r}</option>)}</select></label>
            <label className="text-xs">ชื่อในเกม (IGN) *<input required className={inputClass} value={player.ign||""} onChange={e=>setPlayers(rows=>rows.map((p,j)=>j===i?{...p,ign:e.target.value}:p))}/></label>
            <label className="text-xs">ตำแหน่งที่เล่น<select className={inputClass} value={player.play_position||""} onChange={e=>setPlayers(rows=>rows.map((p,j)=>j===i?{...p,play_position:e.target.value}:p))}><option value="">ไม่ระบุ</option>{ROV_PLAY_POSITIONS.map(r=><option key={r}>{r}</option>)}</select></label>
          </div>}
          <button type="button" disabled={players.length===1} className="mt-2 rounded-lg px-2 py-1 text-sm font-bold text-red-700 hover:bg-red-50" onClick={()=>setPlayers(rows=>rows.filter((_,j)=>j!==i))}>ลบ</button>
        </div>)}
        <div className="mt-4 flex justify-end"><button disabled={busy || rosterImportBusy || !!rosterImportPreview || (!editEntry && !!chosenEvent && !acceptsNewEntries(chosenEvent))} className="rounded-xl bg-blue-700 px-5 py-2.5 text-sm font-bold text-white disabled:opacity-50">{busy ? "กำลังบันทึก..." : chosenEvent && supportsIndividualBatch(chosenEvent) && players.length > 1 ? `ส่งข้อมูลลงทะเบียน ${players.length} คน` : "ส่งข้อมูลลงทะเบียน"}</button></div>
      </form>
    );

    if (tab === "matches" && canManageCompetition) return (
      <form className={formShell} onSubmit={addMatch}>
        <div className="mb-4 flex items-center justify-between"><h3 className="font-bold text-slate-900">เพิ่มโปรแกรมการแข่งขัน</h3><button type="button" onClick={close} className="text-sm text-slate-500">ปิด ✕</button></div>
        <div className="grid gap-3 md:grid-cols-3">
          <label className="md:col-span-2"><span className={labelClass}>รายการแข่งขัน *</span><select name="event_id" required className={inputClass} defaultValue=""><option value="" disabled>เลือกรายการแข่งขัน</option>{events.filter((item) => item.event_type === "team").map((item) => <option key={item.id} value={item.id}>{item.sport_name}</option>)}</select></label>
          <label><span className={labelClass}>รหัสแมตช์</span><input name="match_number" className={inputClass} placeholder="เช่น FB-001" /></label>
          <label><span className={labelClass}>โรงเรียน A *</span><select name="school_a_id" required className={inputClass} defaultValue=""><option value="" disabled>เลือกโรงเรียน</option>{schools.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label>
          <label><span className={labelClass}>โรงเรียน B *</span><select name="school_b_id" required className={inputClass} defaultValue=""><option value="" disabled>เลือกโรงเรียน</option>{schools.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label>
          <label><span className={labelClass}>สาย</span><input name="group_name" className={inputClass} placeholder="สาย A" /></label>
          <label><span className={labelClass}>รอบการแข่งขัน</span><select name="round_name" className={inputClass}><option>รอบแบ่งกลุ่ม</option><option>รอบก่อนรองชนะเลิศ</option><option>รอบรองชนะเลิศ</option><option>รอบชิงชนะเลิศ</option></select></label>
          <label><span className={labelClass}>วันและเวลา</span><input name="scheduled_at" type="datetime-local" className={inputClass} /></label>
          <label><span className={labelClass}>สนามแข่งขัน</span><input name="venue_name" className={inputClass} placeholder="สนาม" /></label>
        </div>
        <div className="mt-4 flex justify-end"><button disabled={busy} className="rounded-xl bg-blue-700 px-5 py-2.5 text-sm font-bold text-white disabled:opacity-50">{busy ? "กำลังบันทึก..." : "บันทึกโปรแกรม"}</button></div>
      </form>
    );

    if (tab === "standings" && canRecordResults) return (
      <form className={formShell} onSubmit={saveEventResult}>
        <div className="mb-4 flex items-center justify-between"><h3 className="font-bold text-slate-900">บันทึกผลกีฬาเดี่ยว / กรีฑา</h3><button type="button" onClick={close} className="text-sm text-slate-500">ปิด ✕</button></div>
        <div className="grid gap-3 md:grid-cols-4">
          <label className="md:col-span-2"><span className={labelClass}>รายการแข่งขัน *</span><select name="event_id" required className={inputClass} defaultValue=""><option value="" disabled>เลือกรายการเดี่ยว / กรีฑา</option>{events.filter((item) => item.event_type !== "team").map((item) => <option key={item.id} value={item.id}>{item.sport_name}</option>)}</select></label>
          <label className="md:col-span-2"><span className={labelClass}>ผู้เข้าแข่งขัน *</span><select name="entry_id" required className={inputClass} defaultValue=""><option value="" disabled>เลือกทีม / นักกีฬา</option>{entries.filter((entry) => entry.status === "approved" && eventById.get(entry.event_id)?.event_type !== "team").map((entry) => <option key={entry.id} value={entry.id}>{eventById.get(entry.event_id)?.sport_name} · {schoolById.get(entry.school_id)?.name} · {entry.entry_name}</option>)}</select></label>
          <label><span className={labelClass}>อันดับ</span><input name="rank" type="number" min="1" step="1" className={inputClass} placeholder="เช่น 1" /></label>
          <label><span className={labelClass}>สถิติ</span><input name="performance_value" type="number" min="0" step="0.001" className={inputClass} placeholder="เช่น 12.45" /></label>
          <label><span className={labelClass}>หน่วย</span><input name="performance_unit" className={inputClass} placeholder="วินาที / เมตร / คะแนน" /></label>
          <label><span className={labelClass}>หมายเหตุผล</span><input name="result_text" className={inputClass} placeholder="เช่น ผ่านเข้ารอบ" /></label>
        </div>
        <div className="mt-4 flex justify-end"><button disabled={busy} className="rounded-xl bg-blue-700 px-5 py-2.5 text-sm font-bold text-white disabled:opacity-50">{busy ? "กำลังบันทึก..." : "บันทึกผลรายบุคคล"}</button></div>
      </form>
    );

    if (tab === "medals" && canManageCompetition) return (
      <form className={formShell} onSubmit={addMedal}>
        <div className="mb-4 flex items-center justify-between"><h3 className="font-bold text-slate-900">บันทึกเหรียญรางวัล</h3><button type="button" onClick={close} className="text-sm text-slate-500">ปิด ✕</button></div>
        <div className="grid gap-3 md:grid-cols-3">
          <label><span className={labelClass}>รายการแข่งขัน *</span><select name="event_id" required className={inputClass} defaultValue=""><option value="" disabled>เลือกรายการ</option>{events.map((item) => <option key={item.id} value={item.id}>{item.sport_name}</option>)}</select></label>
          <label><span className={labelClass}>โรงเรียนที่ได้รับรางวัล *</span><select name="school_id" required className={inputClass} defaultValue=""><option value="" disabled>เลือกโรงเรียน</option>{schools.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label>
          <label><span className={labelClass}>ประเภทเหรียญ</span><select name="medal_type" className={inputClass}><option value="gold">เหรียญทอง</option><option value="silver">เหรียญเงิน</option><option value="bronze">เหรียญทองแดง</option></select></label>
        </div>
        <div className="mt-4 flex justify-end"><button disabled={busy} className="rounded-xl bg-amber-500 px-5 py-2.5 text-sm font-bold text-white disabled:opacity-50">{busy ? "กำลังบันทึก..." : "บันทึกเหรียญ"}</button></div>
      </form>
    );

    return null;
  };

  const headerAction = () => {
    if (tab === "schools" && (isDemo || isAdmin)) return <button onClick={() => setFormOpen((value) => !value)} className="rounded-xl bg-blue-700 px-4 py-2.5 text-sm font-bold text-white">＋ เพิ่มโรงเรียน</button>;
    if (tab === "events" && canManageCompetition) return <button onClick={() => setFormOpen((value) => !value)} className="rounded-xl bg-blue-700 px-4 py-2.5 text-sm font-bold text-white">＋ เพิ่มรายการ</button>;
    if (tab === "entries" && canManageSchool) return <button onClick={() => {setEditEntry(null);setDetail(null);setRosterImportPreview(null);setPlayers([blankPlayer()]);setCoaches([{name:"",phone:""}]);setEventChoice("");setFormOpen(true);}} className="rounded-xl bg-blue-700 px-4 py-2.5 text-sm font-bold text-white">＋ ลงทะเบียนทีม</button>;
    if (tab === "matches" && canManageCompetition) return <button onClick={() => setFormOpen((value) => !value)} className="rounded-xl bg-blue-700 px-4 py-2.5 text-sm font-bold text-white">＋ เพิ่มโปรแกรม</button>;
    if (tab === "standings" && canRecordResults) return <button onClick={() => setFormOpen((value) => !value)} className="rounded-xl bg-blue-700 px-4 py-2.5 text-sm font-bold text-white">＋ บันทึกผลเดี่ยว / กรีฑา</button>;
    if (tab === "medals" && canManageCompetition) return <button onClick={() => setFormOpen((value) => !value)} className="rounded-xl bg-amber-500 px-4 py-2.5 text-sm font-bold text-white">＋ บันทึกเหรียญ</button>;
    return null;
  };

  return (
    <main className="min-h-screen bg-[#f3f6fb] text-slate-800">
      <header className="relative overflow-hidden bg-gradient-to-r from-slate-950 via-blue-950 to-slate-900 text-white">
        <div className="absolute -right-24 -top-28 h-80 w-80 rounded-full bg-blue-500/20 blur-3xl" />
        <div className="absolute -bottom-28 left-1/3 h-64 w-64 rounded-full bg-amber-400/10 blur-3xl" />
        <div className="relative w-full px-4 py-5 md:px-8 md:py-7">
          <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
            <Link href="/" className="text-sm font-semibold text-blue-100 transition hover:text-white">← กลับสู่ระบบกิจกรรม</Link>
            <div className="flex items-center gap-2 text-xs">
              {isDemo ? <span className="rounded-full border border-amber-300/40 bg-amber-300/15 px-3 py-1.5 font-bold text-amber-200">โหมดสาธิต · ข้อมูลตัวอย่าง</span> : <span className="rounded-full border border-emerald-300/40 bg-emerald-300/10 px-3 py-1.5 font-bold text-emerald-200">เชื่อมต่อฐานข้อมูล</span>}
              {userEmail ? <><span className="hidden rounded-full bg-white/10 px-3 py-1.5 text-blue-100 sm:inline">{userEmail}</span><button type="button" onClick={async()=>{await supabase.auth.signOut();window.location.assign("/group-sports/login");}} className="rounded-lg border border-white/25 bg-white/10 px-3 py-1.5 font-semibold text-white hover:bg-white/20">ออกจากระบบ</button></> : <Link href="/group-sports/login" className="rounded-lg bg-white px-3 py-1.5 font-bold text-blue-900 hover:bg-blue-100">เข้าสู่ระบบโรงเรียน</Link>}
            </div>
          </div>
          <div className="flex flex-col justify-between gap-5 md:flex-row md:items-end">
            <div className="max-w-3xl">
              <p className="mb-2 text-xs font-bold uppercase tracking-[0.25em] text-amber-300">Provincial School Sports Management</p>
              <h1 className="text-2xl font-black leading-tight md:text-4xl">ระบบบริหารจัดการแข่งขันกีฬากลุ่ม</h1>
              <p className="mt-2 text-sm text-blue-100 md:text-base">มัธยมศึกษาจังหวัดพะเยา · เชื่อมโยงโรงเรียน รายการแข่งขัน โปรแกรม และผลการแข่งขันไว้ในระบบเดียว</p>
              <p className="mt-4 text-sm font-semibold text-white">{competition?.name || "ยังไม่ได้สร้างรายการแข่งขัน"} {competition?.academic_year ? `· ปีการศึกษา ${competition.academic_year}` : ""}</p>
            </div>
            <div className="flex flex-wrap gap-2">
              <button onClick={() => void loadData()} disabled={loading} className="rounded-xl border border-white/20 bg-white/10 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-white/20 disabled:opacity-50">↻ รีเฟรชข้อมูล</button>
              {headerAction()}
            </div>
          </div>
        </div>
      </header>

      <div className="w-full px-4 pb-12 md:px-8">
        <nav aria-label="เมนูกีฬากลุ่ม" className="relative my-5 overflow-hidden rounded-[24px] border border-[#d8e2f0] bg-[#eef5ff] px-3 py-4 shadow-[0_10px_28px_-16px_rgba(15,23,42,0.35)]">
          <div className="flex gap-2.5 overflow-x-auto pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden xl:grid xl:grid-cols-10 xl:overflow-visible">
          {tabs.map((item) => {
            const isActive = tab === item.key;
            const Icon = item.icon;
            return (
              <button
                key={item.key}
                type="button"
                aria-current={isActive ? "page" : undefined}
                aria-pressed={isActive}
                onClick={() => {
                  setTab(item.key);
                  if (item.key === "schedule") setScheduleView("schedule");
                  setFormOpen(false);
                  setError("");
                }}
                className={`${sportsMenuItem} min-w-[132px] xl:min-w-0 ${isActive ? item.activeClass : "text-slate-900 hover:border-slate-300"}`}
              >
                <div className={`flex h-14 w-14 items-center justify-center rounded-2xl ${isActive ? "bg-white/10" : item.badgeClass}`}>
                  <Icon className={`h-9 w-9 ${isActive ? "text-white" : item.iconClass}`} />
                </div>
                <span className={`line-clamp-2 text-[13px] font-black leading-tight sm:text-[15px] ${isActive ? "text-white" : "text-slate-900"}`}>{item.label}</span>
                {isActive && <span aria-hidden="true" className="absolute bottom-2 left-1/2 h-1 w-12 -translate-x-1/2 rounded-full bg-yellow-300" />}
              </button>
            );
          })}
          </div>
        </nav>

        {isDemo && <div className="mb-4 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900"><strong>โหมดสาธิต:</strong> ข้อมูลโรงเรียน รายการแข่งขัน และผลการแข่งขันที่แสดงเป็นข้อมูลสมมติ การเพิ่มหรือแก้ไขในโหมดนี้จะอยู่เฉพาะหน้าจอและไม่บันทึกลง Supabase กรุณาติดตั้ง SQL Migration ก่อนใช้งานจริง</div>}
        {notice && <div className="mb-4 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">{notice}</div>}
        {error && <div role="alert" className="mb-4 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-800">{error}</div>}
        {renderForm()}

        {loading ? (
          <div className="rounded-2xl border border-slate-200 bg-white p-12 text-center text-sm text-slate-500 shadow-sm">กำลังโหลดข้อมูลการแข่งขัน...</div>
        ) : (
          <>
            {tab === "accounts" && (canManageAccounts ? <SchoolAccountsManager /> : (
              <section className="rounded-[28px] border border-slate-200 bg-white p-6 shadow-sm">
                <div className="mx-auto max-w-3xl text-center">
                  <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-3xl bg-gradient-to-br from-blue-100 via-indigo-100 to-fuchsia-100 text-blue-700">
                    <UserShieldIcon className="h-10 w-10" />
                  </div>
                  <h2 className="text-2xl font-black text-slate-900">เมนูบัญชีโรงเรียน</h2>
                  <p className="mt-3 text-sm leading-7 text-slate-600">เมนูนี้ใช้สำหรับผู้ดูแลระบบในการสร้าง Username และ Password ให้โรงเรียนที่เข้าร่วมการแข่งขัน หากต้องการใช้งาน กรุณาเข้าสู่ระบบด้วยบัญชีผู้ดูแลหรือบัญชีกรรมการที่มีสิทธิ์จัดการการแข่งขัน</p>
                  <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
                    {userEmail ? <button type="button" onClick={async()=>{await supabase.auth.signOut();window.location.assign("/group-sports/login");}} className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm font-bold text-slate-700 hover:bg-slate-50">ออกจากระบบแล้วเข้าสู่ระบบใหม่</button> : <Link href="/group-sports/login" className="rounded-xl bg-gradient-to-r from-blue-600 to-indigo-700 px-5 py-2.5 text-sm font-extrabold text-white shadow-sm hover:brightness-110">เข้าสู่ระบบผู้ดูแล</Link>}
                    <button type="button" onClick={() => setTab("overview")} className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm font-bold text-slate-700 hover:bg-slate-50">กลับหน้าหลัก</button>
                  </div>
                </div>
              </section>
            ))}
            {tab === "submissions" && <SchoolSubmissionsContent embedded />}
            {tab === "schedule" && <SportsScheduleContent key={scheduleView} embedded initialTab={scheduleView} />}
            {tab === "overview" && (
              <>
                <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
                  {[
                    { label: "โรงเรียนในระบบ", value: schools.length, icon: "🏫", color: "text-blue-700", bg: "bg-blue-50" },
                    { label: "รายการแข่งขัน", value: events.length, icon: "🏅", color: "text-violet-700", bg: "bg-violet-50" },
                    { label: "ทีม / รายการที่ลงทะเบียน", value: entries.length, icon: "👥", color: "text-emerald-700", bg: "bg-emerald-50" },
                    { label: "แข่งขันเสร็จแล้ว", value: completedMatches.length, icon: "⚑", color: "text-amber-700", bg: "bg-amber-50" },
                    { label: "เหรียญรางวัล", value: totalMedals, icon: "🥇", color: "text-orange-700", bg: "bg-orange-50" },
                  ].map((item) => (
                    <div key={item.label} className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
                      <div className="flex items-center justify-between"><span className={`flex h-10 w-10 items-center justify-center rounded-xl text-xl ${item.bg}`}>{item.icon}</span><span className={`text-2xl font-black tabular-nums ${item.color}`}>{item.value.toLocaleString("th-TH")}</span></div>
                      <p className="mt-3 text-xs font-semibold text-slate-500">{item.label}</p>
                    </div>
                  ))}
                </section>
                <section className="mt-5 grid gap-5 lg:grid-cols-[1.25fr_0.75fr]">
                  <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                    <div className="mb-4 flex items-center justify-between"><div><h2 className="text-lg font-black text-slate-900">รายการแข่งขัน</h2><p className="text-xs text-slate-500">ภาพรวมประเภทกีฬาและรุ่นการแข่งขัน</p></div><button onClick={() => setTab("events")} className="text-xs font-bold text-blue-700">ดูทั้งหมด →</button></div>
                    <div className="space-y-3">
                      {events.slice(0, 5).map((item) => (
                        <div key={item.id} className="flex items-center justify-between gap-3 rounded-xl border border-slate-100 p-3">
                          <div className="min-w-0"><p className="truncate text-sm font-bold text-slate-800">{item.sport_name}</p><p className="mt-1 text-xs text-slate-500">{eventTypeLabel(item.event_type)} · {item.gender_rule} · {item.level_rule}</p></div>
                          <span className="shrink-0 rounded-full bg-blue-50 px-2.5 py-1 text-[11px] font-bold text-blue-700">{statusLabel(item.status)}</span>
                        </div>
                      ))}
                      {!events.length && <EmptyState title="ยังไม่มีรายการแข่งขัน" description="เพิ่มประเภทกีฬาและรุ่นการแข่งขันเพื่อเริ่มต้น" />}
                    </div>
                  </div>
                  <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                    <div className="mb-4 flex items-center justify-between"><div><h2 className="text-lg font-black text-slate-900">ตารางเหรียญ</h2><p className="text-xs text-slate-500">สรุปผลตามโรงเรียน</p></div><button onClick={() => setTab("medals")} className="text-xs font-bold text-blue-700">ดูทั้งหมด →</button></div>
                    <MedalTable rows={medalTable.slice(0, 5)} />
                    {!medalTable.length && <EmptyState title="ยังไม่มีเหรียญรางวัล" description="เมื่อบันทึกผลและมอบรางวัลแล้วจะแสดงที่นี่" />}
                  </div>
                </section>
                <section className="mt-5 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                  <div className="mb-4 flex items-center justify-between"><div><h2 className="text-lg font-black text-slate-900">โปรแกรมการแข่งขันล่าสุด</h2><p className="text-xs text-slate-500">กำหนดการและสถานะการแข่งขัน</p></div><button onClick={() => setTab("matches")} className="text-xs font-bold text-blue-700">ดูโปรแกรมทั้งหมด →</button></div>
                  <MatchTable matches={matches.slice(0, 5)} schools={schoolById} events={eventById} results={resultByMatch} />
                </section>
              </>
            )}

            {tab === "schools" && (
              <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                <div className="mb-5 flex flex-wrap items-end justify-between gap-3"><div><h2 className="text-xl font-black text-slate-900">โรงเรียนที่เข้าร่วม</h2><p className="mt-1 text-sm text-slate-500">ทะเบียนโรงเรียนกลางสำหรับการแข่งขันระดับจังหวัด</p></div><span className="rounded-full bg-blue-50 px-3 py-1.5 text-xs font-bold text-blue-700">{schools.length} โรงเรียน</span></div>
                <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
                  {schools.map((school) => (
                    <div key={school.id} className="rounded-2xl border border-slate-200 p-4 transition hover:border-blue-200 hover:shadow-sm">
                      <div className="flex items-start gap-3"><span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-blue-50 text-xl">🏫</span><div className="min-w-0"><h3 className="font-bold text-slate-900">{school.name}</h3><p className="mt-1 text-xs text-slate-500">{school.district || "ไม่ระบุอำเภอ"} · {school.province || "พะเยา"}</p><p className="mt-2 text-[11px] text-slate-400">รหัส {school.school_code || "ยังไม่กำหนด"}</p></div></div>
                    </div>
                  ))}
                </div>
                {!schools.length && <EmptyState title="ยังไม่มีโรงเรียนในทะเบียน" description="ผู้ดูแลการแข่งขันสามารถเพิ่มโรงเรียนที่เข้าร่วมได้" />}
              </section>
            )}

            {tab === "events" && (
              <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                <div className="mb-5 flex flex-wrap items-end justify-between gap-3"><div><h2 className="text-xl font-black text-slate-900">รายการแข่งขัน</h2><p className="mt-1 text-sm text-slate-500">กำหนดประเภทกีฬา เพศ รุ่น และรูปแบบการแข่งขัน</p></div><span className="rounded-full bg-violet-50 px-3 py-1.5 text-xs font-bold text-violet-700">{events.length} รายการ</span></div>
                <div className="overflow-x-auto"><table className="w-full min-w-[760px] text-left text-sm"><thead><tr className="border-b border-slate-200 text-xs text-slate-500"><th className="pb-3 pr-3">รหัส</th><th className="pb-3 pr-3">รายการแข่งขัน</th><th className="pb-3 pr-3">ประเภท</th><th className="pb-3 pr-3">เพศ / รุ่น</th><th className="pb-3 pr-3">รูปแบบ</th><th className="pb-3">สถานะ</th></tr></thead><tbody>{events.map((item) => <tr key={item.id} className="border-b border-slate-100 last:border-0"><td className="py-3 pr-3 text-xs font-semibold text-slate-500">{item.event_code || "-"}</td><td className="py-3 pr-3 font-bold text-slate-800">{item.sport_name}</td><td className="py-3 pr-3">{eventTypeLabel(item.event_type)}</td><td className="py-3 pr-3">{item.gender_rule} · {item.level_rule}</td><td className="py-3 pr-3 text-xs text-slate-500">{item.competition_format || "-"}</td><td className="py-3"><span className="rounded-full bg-blue-50 px-2.5 py-1 text-[11px] font-bold text-blue-700">{statusLabel(item.status)}</span></td></tr>)}</tbody></table></div>
                {!events.length && <EmptyState title="ยังไม่มีรายการแข่งขัน" description="เพิ่มรายการกีฬาและกำหนดรุ่นการแข่งขันก่อนเปิดรับสมัคร" />}
              </section>
            )}

            {tab === "entries" && (
              <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                <div className="mb-5 flex flex-wrap items-end justify-between gap-3"><div><h2 className="text-xl font-black text-slate-900">การลงทะเบียนทีมและนักกีฬา</h2><p className="mt-1 text-sm text-slate-500">ตรวจสอบรายชื่อที่แต่ละโรงเรียนส่งเข้าร่วมการแข่งขัน</p></div><span className="rounded-full bg-emerald-50 px-3 py-1.5 text-xs font-bold text-emerald-700">อนุมัติแล้ว {approvedEntries} / {schoolEntries.length}</span></div>
                <div className="mb-4 grid gap-2 sm:grid-cols-3">
                  <select aria-label="โรงเรียน" className="rounded-lg border p-2" value={schoolFilter} onChange={e=>setSchoolFilter(e.target.value)}><option value="">ทุกโรงเรียนที่ดูแล</option>{entrySchools.map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</select>
                  <select aria-label="รายการแข่งขัน" className="rounded-lg border p-2" value={eventFilter} onChange={e=>setEventFilter(e.target.value)}><option value="">ทุกรายการแข่งขัน</option>{events.map(e=><option key={e.id} value={e.id}>{e.sport_name}</option>)}</select>
                  <select aria-label="สถานะใบสมัคร" className="rounded-lg border p-2" value={statusFilter} onChange={e=>setStatusFilter(e.target.value)}><option value="">ทุกสถานะ</option>{["submitted","approved","rejected"].map(s=><option key={s} value={s}>{statusLabel(s)}</option>)}</select>
                </div>
                {registrationRows.map(entry=><article key={entry.id} className="flex flex-wrap items-center justify-between gap-3 border-t py-3">
                  <div><strong>{schoolById.get(entry.school_id)?.name} · {entry.entry_name}</strong><p className="text-sm">{eventById.get(entry.event_id)?.sport_name} · {entry.coach_name||"ไม่ระบุครูผู้ควบคุม"} · {entry.athlete_count} คน</p>
                    <p className="text-sm font-bold text-blue-800">{statusLabel(entry.status)} {entry.return_reason && `· ${entry.return_reason}`}</p></div>
                  <div className="flex gap-3"><button disabled={busy} onClick={()=>void openRoster(entry)}>ดูรายชื่อ</button>{entry.status==="rejected" && canManageSchool && <button className="text-blue-700" disabled={busy} onClick={()=>void openRoster(entry,true)}>แก้ไขและส่งใหม่</button>}</div>
                </article>)}
                {!registrationRows.length && <p className="rounded-xl bg-slate-50 p-5">ยังไม่มีใบสมัครตามเงื่อนไขนี้</p>}
                {detail && <section className="mt-4 rounded-xl border bg-blue-50 p-4"><div className="flex justify-between"><strong>รายชื่อ · {detail.entry.entry_name}</strong><button onClick={()=>setDetail(null)}>ปิด</button></div>
                  {detail.entry.coaches?.length ? detail.entry.coaches.map((c,i)=><p key={i}>ครูผู้ควบคุมทีม {i+1} · {c.name} {c.phone}</p>) : <p>ผู้ฝึกสอน {detail.entry.coach_name||"—"} {detail.entry.assistant_coach && ` · ผู้ช่วย ${detail.entry.assistant_coach}`}</p>}
                  <ol className="my-3 list-decimal pl-6">{detail.players.map((p,i)=><li key={i}>{[p.student_code,p.full_name,...(isRov(eventById.get(detail.entry.event_id)) ? [p.team_role,p.ign,p.play_position] : [])].filter(Boolean).join(" · ")}</li>)}</ol>
                  {rosterAdmin && detail.entry.status==="submitted" && <div className="flex flex-wrap gap-2"><input className="rounded-lg border bg-white p-2" aria-label="เหตุผลที่ส่งคืน" placeholder="เหตุผลที่ส่งคืน" value={reason} onChange={e=>setReason(e.target.value)}/><button className="rounded-lg bg-amber-100 p-2" disabled={busy||!reason.trim()} onClick={()=>void updateEntryStatus(detail.entry.id,"rejected")}>ส่งคืนให้แก้ไข</button><button className="rounded-lg bg-emerald-700 p-2 text-white" disabled={busy} onClick={()=>void updateEntryStatus(detail.entry.id,"approved")}>อนุมัติ</button></div>}
                </section>}
              </section>
            )}

            {tab === "matches" && (
              <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                <div className="mb-5 flex flex-wrap items-end justify-between gap-3"><div><h2 className="text-xl font-black text-slate-900">โปรแกรมและผลการแข่งขัน</h2><p className="mt-1 text-sm text-slate-500">จัดสาย รอบ วันเวลา สนาม และบันทึกคะแนน</p></div><span className="rounded-full bg-amber-50 px-3 py-1.5 text-xs font-bold text-amber-700">เสร็จสิ้น {completedMatches.length} / {matches.length} แมตช์</span></div>
                <MatchTable matches={matches} schools={schoolById} events={eventById} results={resultByMatch} />
                {canRecordResults && <form onSubmit={saveMatchResult} className="mt-6 rounded-2xl border border-amber-200 bg-amber-50/70 p-4"><h3 className="mb-3 font-bold text-slate-900">บันทึกผลการแข่งขัน</h3><div className="grid gap-3 md:grid-cols-[2fr_1fr_1fr_auto] md:items-end"><label><span className="mb-1 block text-xs font-bold text-slate-600">เลือกแมตช์</span><select required value={resultMatchId} onChange={(event) => setResultMatchId(event.target.value)} className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm"><option value="">เลือกแมตช์ที่ต้องการบันทึกผล</option>{matches.filter((match) => match.status !== "cancelled").map((match) => <option key={match.id} value={match.id}>{eventById.get(match.event_id)?.sport_name || "รายการแข่งขัน"} · {schoolById.get(match.school_a_id || "")?.name || "รอระบุ"} พบ {schoolById.get(match.school_b_id || "")?.name || "รอระบุ"}</option>)}</select></label><label><span className="mb-1 block text-xs font-bold text-slate-600">คะแนน A</span><input type="number" min="0" step="0.01" value={resultScoreA} onChange={(event) => setResultScoreA(event.target.value)} className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm" /></label><label><span className="mb-1 block text-xs font-bold text-slate-600">คะแนน B</span><input type="number" min="0" step="0.01" value={resultScoreB} onChange={(event) => setResultScoreB(event.target.value)} className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm" /></label><button disabled={busy || !resultMatchId} className="rounded-xl bg-amber-500 px-5 py-2.5 text-sm font-bold text-white disabled:opacity-50">บันทึกผล</button></div><p className="mt-2 text-xs text-slate-500">ระบบจะคำนวณผู้ชนะและอัปเดตสถานะแมตช์เป็นเสร็จสิ้นโดยอัตโนมัติ</p></form>}
                {!matches.length && <EmptyState title="ยังไม่มีโปรแกรมการแข่งขัน" description="เพิ่มรายการแข่งขันและโรงเรียนก่อนจัดโปรแกรม" />}
              </section>
            )}

            {tab === "standings" && (
              <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
                <div className="mb-5 flex flex-wrap items-end justify-between gap-3"><div><h2 className="text-xl font-black text-slate-900">ตารางคะแนน</h2><p className="mt-1 text-sm text-slate-500">คำนวณจากผลการแข่งขันที่บันทึกแล้ว โดยใช้เกณฑ์คะแนนของแต่ละรายการ</p></div><select value={selectedEventId} onChange={(event) => setSelectedEventId(event.target.value)} className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm"><option value="all">ทุกรายการ</option>{events.map((item) => <option key={item.id} value={item.id}>{item.sport_name}</option>)}</select></div>
                {eventResults.filter((item) => selectedEventId === "all" || item.event_id === selectedEventId).length > 0 && <div className="mb-5 overflow-hidden rounded-xl border border-slate-200"><div className="bg-slate-50 px-4 py-3"><h3 className="font-bold text-slate-900">ผลกีฬาเดี่ยว / กรีฑา</h3><p className="text-xs text-slate-500">อันดับและสถิติที่กรรมการบันทึก</p></div><div className="overflow-x-auto"><table className="w-full min-w-[620px] text-left text-sm"><thead><tr className="border-b border-slate-100 text-xs text-slate-500"><th className="px-4 py-2">รายการ</th><th className="px-4 py-2">โรงเรียน</th><th className="px-4 py-2">ผู้เข้าแข่งขัน</th><th className="px-4 py-2">อันดับ</th><th className="px-4 py-2">สถิติ</th><th className="px-4 py-2">หมายเหตุ</th></tr></thead><tbody>{eventResults.filter((item) => selectedEventId === "all" || item.event_id === selectedEventId).sort((a, b) => (a.rank || 999) - (b.rank || 999)).map((item) => <tr key={item.id} className="border-b border-slate-100 last:border-0"><td className="px-4 py-3 font-semibold">{eventById.get(item.event_id)?.sport_name || "-"}</td><td className="px-4 py-3">{schoolById.get(item.school_id)?.name || "-"}</td><td className="px-4 py-3 font-bold">{item.entry_name}</td><td className="px-4 py-3 font-black text-blue-700">{item.rank || "-"}</td><td className="px-4 py-3">{item.performance_value ?? "-"} {item.performance_unit || ""}</td><td className="px-4 py-3 text-slate-500">{item.result_text || "-"}</td></tr>)}</tbody></table></div></div>}
                <div className="space-y-5">{standings.map(({ event: sportEvent, groupName, rows }) => <div key={`${sportEvent.id}-${groupName}`} className="overflow-hidden rounded-xl border border-slate-200"><div className="bg-slate-50 px-4 py-3"><h3 className="font-bold text-slate-900">{sportEvent.sport_name} · {groupName}</h3><p className="text-xs text-slate-500">คะแนนชนะ {sportEvent.points_win ?? 3} · เสมอ {sportEvent.points_draw ?? 1} · แพ้ {sportEvent.points_loss ?? 0}</p></div><div className="overflow-x-auto"><table className="w-full min-w-[640px] text-left text-sm"><thead><tr className="border-b border-slate-100 text-xs text-slate-500"><th className="px-4 py-2">อันดับ</th><th className="px-4 py-2">โรงเรียน</th><th className="px-4 py-2">แข่ง</th><th className="px-4 py-2">ชนะ</th><th className="px-4 py-2">เสมอ</th><th className="px-4 py-2">แพ้</th><th className="px-4 py-2">ได้ / เสีย</th><th className="px-4 py-2">คะแนน</th></tr></thead><tbody>{rows.map((row, index) => <tr key={row.school.id} className="border-b border-slate-100 last:border-0"><td className="px-4 py-3 font-black">{index + 1}</td><td className="px-4 py-3 font-bold">{row.school.name}</td><td className="px-4 py-3">{row.played}</td><td className="px-4 py-3">{row.win}</td><td className="px-4 py-3">{row.draw}</td><td className="px-4 py-3">{row.loss}</td><td className="px-4 py-3">{row.scored} / {row.conceded}</td><td className="px-4 py-3 font-black text-blue-700">{row.points}</td></tr>)}</tbody></table></div></div>)}{!standings.length && <EmptyState title="ยังไม่มีตารางคะแนน" description="เมื่อบันทึกผลการแข่งขันประเภททีมแล้ว ระบบจะคำนวณตารางคะแนนให้" />}</div>
              </section>
            )}

            {tab === "medals" && (
              <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><div className="mb-5"><h2 className="text-xl font-black text-slate-900">สรุปเหรียญรางวัล</h2><p className="mt-1 text-sm text-slate-500">จัดอันดับโรงเรียนตามจำนวนเหรียญทอง เงิน และทองแดง</p></div><MedalTable rows={medalTable} showEmpty /><div className="mt-6 border-t border-slate-100 pt-5"><h3 className="mb-3 font-bold text-slate-900">รายการเหรียญที่บันทึกแล้ว</h3>{medals.length ? <div className="space-y-2">{medals.map((medal) => <div key={medal.id} className="flex items-center justify-between gap-3 rounded-xl border border-slate-100 p-3"><div className="min-w-0"><p className="truncate text-sm font-bold">{eventById.get(medal.event_id)?.sport_name || "รายการแข่งขัน"}</p><p className="text-xs text-slate-500">{schoolById.get(medal.school_id)?.name || "-"}</p></div><MedalBadge type={medal.medal_type} /></div>)}</div> : <p className="text-sm text-slate-500">ยังไม่มีการบันทึกเหรียญรางวัล</p>}</div></section>
            )}
          </>
        )}

        <footer className="mt-8 flex flex-col justify-between gap-2 border-t border-slate-200 py-5 text-xs text-slate-500 md:flex-row"><span>ระบบกีฬากลุ่มมัธยมศึกษาจังหวัดพะเยา</span><span>พัฒนาแยกจากระบบกิจกรรมพัฒนาผู้เรียน · CKW Student Activity App</span></footer>
      </div>
    </main>
  );
}

function EmptyState({ title, description }: { title: string; description: string }) {
  return <div className="rounded-xl border border-dashed border-slate-200 bg-slate-50 px-4 py-8 text-center"><p className="font-bold text-slate-700">{title}</p><p className="mt-1 text-xs text-slate-500">{description}</p></div>;
}

function MedalBadge({ type }: { type: string }) {
  const config: Record<string, { label: string; className: string; icon: string }> = {
    gold: { label: "เหรียญทอง", className: "bg-amber-100 text-amber-800", icon: "🥇" },
    silver: { label: "เหรียญเงิน", className: "bg-slate-100 text-slate-700", icon: "🥈" },
    bronze: { label: "เหรียญทองแดง", className: "bg-orange-100 text-orange-800", icon: "🥉" },
  };
  const item = config[type] || config.gold;
  return <span className={`shrink-0 rounded-full px-3 py-1 text-xs font-bold ${item.className}`}>{item.icon} {item.label}</span>;
}

function MedalTable({ rows, showEmpty = false }: { rows: { school: School; gold: number; silver: number; bronze: number; total: number }[]; showEmpty?: boolean }) {
  if (!rows.length) return showEmpty ? <EmptyState title="ยังไม่มีผลการมอบเหรียญ" description="เมื่อบันทึกเหรียญรางวัลแล้ว ตารางอันดับจะแสดงโดยอัตโนมัติ" /> : null;
  return <div className="overflow-x-auto"><table className="w-full min-w-[420px] text-left text-sm"><thead><tr className="border-b border-slate-200 text-xs text-slate-500"><th className="pb-3 pr-2">อันดับ</th><th className="pb-3 pr-2">โรงเรียน</th><th className="pb-3 px-2 text-center">🥇</th><th className="pb-3 px-2 text-center">🥈</th><th className="pb-3 px-2 text-center">🥉</th><th className="pb-3 pl-2 text-right">รวม</th></tr></thead><tbody>{rows.map((row, index) => <tr key={row.school.id} className="border-b border-slate-100 last:border-0"><td className="py-3 pr-2 font-black text-slate-500">{index + 1}</td><td className="py-3 pr-2 font-bold text-slate-800">{row.school.name}</td><td className="px-2 py-3 text-center font-bold text-amber-700">{row.gold}</td><td className="px-2 py-3 text-center font-bold text-slate-600">{row.silver}</td><td className="px-2 py-3 text-center font-bold text-orange-700">{row.bronze}</td><td className="py-3 pl-2 text-right font-black">{row.total}</td></tr>)}</tbody></table></div>;
}

function MatchTable({ matches, schools, events, results }: { matches: Match[]; schools: Map<string, School>; events: Map<string, SportEvent>; results: Map<string, MatchResult> }) {
  if (!matches.length) return null;
  return <div className="overflow-x-auto"><table className="w-full min-w-[760px] text-left text-sm"><thead><tr className="border-b border-slate-200 text-xs text-slate-500"><th className="pb-3 pr-3">รายการ / รอบ</th><th className="pb-3 pr-3">คู่แข่งขัน</th><th className="pb-3 pr-3">วันเวลา / สนาม</th><th className="pb-3 pr-3">ผล</th><th className="pb-3">สถานะ</th></tr></thead><tbody>{matches.map((match) => { const result = results.get(match.id); return <tr key={match.id} className="border-b border-slate-100 last:border-0"><td className="py-3 pr-3"><p className="font-bold text-slate-800">{events.get(match.event_id)?.sport_name || "รายการแข่งขัน"}</p><p className="mt-1 text-xs text-slate-500">{match.match_number || "-"} · {match.group_name || "ไม่แบ่งสาย"} · {match.round_name}</p></td><td className="py-3 pr-3"><p className="font-semibold">{schools.get(match.school_a_id || "")?.name || "รอระบุ"}</p><p className="my-1 text-[10px] font-bold text-slate-400">พบ</p><p className="font-semibold">{schools.get(match.school_b_id || "")?.name || "รอระบุ"}</p></td><td className="py-3 pr-3 text-xs text-slate-500">{formatThaiDate(match.scheduled_at)}<p className="mt-1">{match.venue_name || "ยังไม่กำหนดสนาม"}</p></td><td className="py-3 pr-3 font-black text-blue-800">{result ? `${result.score_a} : ${result.score_b}` : "-"}</td><td className="py-3"><span className={`rounded-full px-2.5 py-1 text-[11px] font-bold ${match.status === "completed" ? "bg-emerald-50 text-emerald-700" : match.status === "live" ? "bg-rose-50 text-rose-700" : "bg-slate-100 text-slate-600"}`}>{statusLabel(match.status)}</span></td></tr>; })}</tbody></table></div>;
}
